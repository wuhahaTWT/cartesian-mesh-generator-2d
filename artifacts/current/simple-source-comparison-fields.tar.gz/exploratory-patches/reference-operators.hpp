#pragma once
#include "FlowEquation2D.hpp"
namespace cartmesh2d::fv::solver_detail {
// Independent native 2-D implementation of the documented Gauss-linear
// choices. Research only: no OpenFOAM kernel is linked or copied.
inline Vec referenceFaces(const FvMesh2D& m,const Vec& x,const Vec& bc,const std::vector<bool>& fixed) {
 Vec f(m.faces.size());for(std::size_t id=0;id<f.size();++id)f[id]=m.faces[id].neighbour?interpolate(m.faces[id],x):fixed[id]?bc[id]:x[m.faces[id].owner];return f;
}
inline std::vector<Vector2D> referenceGradient(const FvMesh2D& m,const Vec& x,const Vec& bc,const std::vector<bool>& fixed) {
 return detail::conservativePressureGradient(m,referenceFaces(m,x,bc,fixed));
}
inline std::vector<Vector2D> referenceStress(const FvMesh2D& m,const FlowResult2D& r,const FlowReconstruction2D& g,const Boundary& b,const FlowControls2D& c) {
 std::vector<Vector2D> stress(m.faces.size());
 for(std::size_t id=0;id<m.faces.size();++id){const auto& f=m.faces[id];
  const auto gu=f.neighbour?interpolateGradient(f,g.gu):detail::viscousFaceGradient(m,id,r.u,g.gu,b.u,b.fixedU,b.constantU);
  const auto gv=f.neighbour?interpolateGradient(f,g.gv):detail::viscousFaceGradient(m,id,r.v,g.gv,b.v,b.fixedV,b.constantV);
  const double nu=faceNu(c,id);stress[id]={-nu*(gu.x*f.areaVector.x+gv.x*f.areaVector.y),-nu*(gu.y*f.areaVector.x+gv.y*f.areaVector.y)};
  if(!f.neighbour){if(b.constantU[id]&&b.fixedU[id])stress[id].x+=nu*dot(g.gu[f.owner],f.correction);if(b.constantV[id]&&b.fixedV[id])stress[id].y+=nu*dot(g.gv[f.owner],f.correction);}
 }return stress;
}
}
