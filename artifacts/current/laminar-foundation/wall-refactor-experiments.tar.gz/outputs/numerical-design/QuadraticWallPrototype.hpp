#pragma once
// Independent research closure. The original compact interior operators remain
// unchanged. A geometry-only QR stencil replaces the complete wall stress, with
// one shared additive defect consumed by momentum assembly and force output.
#include "FlowSolverDetail2D.hpp"
#include "cartmesh2d/fv/WallGradient2D.hpp"
#include <optional>
namespace cartmesh2d::fv::solver_detail {
inline Vector2D operator+(Vector2D a,Vector2D b){return {a.x+b.x,a.y+b.y};}
inline Vector2D operator-(Vector2D a,Vector2D b){return {a.x-b.x,a.y-b.y};}
struct QuadraticWallPrototype {
    const FvMesh2D* mesh=nullptr;
    std::vector<std::optional<WallGradientStencil2D>> stencils;
    const std::vector<std::optional<WallGradientStencil2D>>& prepare(const FvMesh2D& m,const Boundary& b) {
        if(mesh==&m)return stencils;
        mesh=&m;stencils.clear();stencils.resize(m.faces.size());
        const std::vector<std::optional<std::size_t>> partners(m.faces.size());
        for(std::size_t id=0;id<m.faces.size();++id)
            if(!m.faces[id].neighbour && (b.role[id]==Role::Wall || b.role[id]==Role::Lid) && b.fixedU[id] && b.fixedV[id])
                stencils[id]=quadraticWallGradient2D(m,id,b.fixedU,partners);
        return stencils;
    }
    std::vector<Vector2D> defect(const FvMesh2D& m,const FlowControls2D& c,const Boundary& b,
        const Vec& u,const Vec& v,const std::vector<Vector2D>& gu,const std::vector<Vector2D>& gv,
        const std::vector<Vector2D>& stress) {
        
#ifdef QW_DIVFREE_BASE
        std::vector<Vector2D> constrained(m.faces.size());
        if(c.viscousStress==ViscousStress2D::Symmetric)for(std::size_t id=0;id<m.faces.size();++id) {
            const auto& f=m.faces[id];
            if(f.neighbour || (b.role[id]!=Role::Wall && b.role[id]!=Role::Lid) || !b.fixedU[id] || !b.fixedV[id])continue;
            const auto a=detail::viscousFaceGradient(m,id,u,gu,b.u,b.fixedU,b.constantU);
            const auto d=detail::viscousFaceGradient(m,id,v,gv,b.v,b.fixedV,b.constantV);
            const double div=a.x+d.y;
            // Change only normal-normal gradient component: grad(U) -= div*n*n^T.
            // The physical incompressibility constraint leaves tangent derivatives
            // and shear traction untouched and removes its symmetric normal stress.
            constrained[id]=f.areaVector*(2*faceNu(c,id)*div);
        }
        return constrained;
#else
        const auto& geometry=prepare(m,b);std::vector<Vector2D> delta(m.faces.size());
        for(std::size_t id=0;id<m.faces.size();++id)if(geometry[id]) {
            const auto& f=m.faces[id];const double nu=faceNu(c,id);
            const auto recover=[&](const Vec& value,const Vec& boundary,bool constant) {
                Vector2D g{};
                for(const auto& sample:geometry[id]->samples) {
                    const double x=(sample.boundary?boundary[sample.index]:value[sample.index])-boundary[id];
                    g.x+=sample.weight.x*x;g.y+=sample.weight.y*x;
                }
                if(constant){const auto n=f.areaVector*(1/std::hypot(f.areaVector.x,f.areaVector.y));g=n*dot(g,n);}
                return g;
            };
            const auto a=recover(u,b.u,b.constantU[id]),d=recover(v,b.v,b.constantV[id]);
            Vector2D desired{-nu*dot(a,f.areaVector),-nu*dot(d,f.areaVector)};
            if(c.viscousStress==ViscousStress2D::Symmetric) {
                desired.x-=nu*(a.x*f.areaVector.x+d.x*f.areaVector.y);
                desired.y-=nu*(a.y*f.areaVector.x+d.y*f.areaVector.y);
            }
            Vector2D original{-nu*(f.transmissibility*(b.u[id]-u[f.owner])+dot(gu[f.owner],f.correction)),
                               -nu*(f.transmissibility*(b.v[id]-v[f.owner])+dot(gv[f.owner],f.correction))};
            if(!stress.empty())original=original+stress[id];
            delta[id]=desired-original;
        }
        return delta;
#endif
    }
};
inline QuadraticWallPrototype& quadraticWallPrototype(){static thread_local QuadraticWallPrototype prototype;return prototype;}
}
