#include "QuadraticWallPrototype.hpp"
#include "cartmesh2d/fv/FlowBoundaryIO2D.hpp"
#include "cartmesh2d/io/MeshIO2D.hpp"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <map>
using namespace cartmesh2d;
using namespace cartmesh2d::fv;
using namespace cartmesh2d::fv::solver_detail;
struct Analytic {
    double u,v,p;Vector2D gu,gv,gp;
};
Analytic vortex(Point2D c) {
    constexpr double A=-1./3.,B=1./3.;const double r2=c.x*c.x+c.y*c.y,r=std::sqrt(r2),q=A+B/r2;
    const double qx=-2*B*c.x/(r2*r2),qy=-2*B*c.y/(r2*r2);
    const double dp=q*q;
    return {-c.y*q,c.x*q,.5*A*A*r2+2*A*B*std::log(r)-.5*B*B/r2,
        {-c.y*qx,-q-c.y*qy},{q+c.x*qx,c.x*qy},{dp*c.x,dp*c.y}};
}
Vector2D stressFlux(const Analytic& a,const Face& f,double nu,bool symmetric) {
    Vector2D value{-nu*dot(a.gu,f.areaVector),-nu*dot(a.gv,f.areaVector)};
    if(symmetric)value=value+Vector2D{-nu*(a.gu.x*f.areaVector.x+a.gv.x*f.areaVector.y),-nu*(a.gu.y*f.areaVector.x+a.gv.y*f.areaVector.y)};
    return value;
}
struct Stats {
    long double norm=0,length=0;double max=0;
    void add(Vector2D error,double w){length+=w;const double e=std::hypot(error.x,error.y);norm+=w*e*e;max=std::max(max,e);}
    void write(){std::cout<<"{\"rms\":"<<std::sqrt(static_cast<double>(norm/length))<<",\"maximum\":"<<max<<"}";}
};
int main(int argc,char** argv){try {
    if(argc<3 || argc>4)throw std::runtime_error("wall-audit MESH BOUNDARIES");
    const auto input=readCm2dTopology(argv[1]);if(!input.valid())throw std::runtime_error(input.error);
    const auto m=makeFvMesh2D(input.topology);const auto n=m.cells.size(),nf=m.faces.size();
    FlowControls2D c;c.scenario="custom";c.nu=.1;c.speed=.5;
    std::ifstream in(argv[2]);c.boundaryConditions=readFlowBoundaryConditions2D(in,m,c);
    auto b=boundaries(m,c);
    if(argc==4)for(std::size_t id=0;id<nf;++id)if(!m.faces[id].neighbour){const auto a=vortex(m.faces[id].centre);b.u[id]=a.u;b.v[id]=a.v;b.constantU[id]=b.constantV[id]=false;}
    Vec u(n),v(n),p(n),zero(nf);
    for(std::size_t i=0;i<n;++i){const auto a=vortex(m.cells[i].centre);u[i]=a.u;v[i]=a.v;p[i]=a.p;}
    const auto gu=detail::flowGradient(m,u,b.u,b.fixedU),gv=detail::flowGradient(m,v,b.v,b.fixedV);
    const auto gp=detail::flowGradient(m,p,zero,b.fixedP,true);
    const auto pf=detail::pressureFaceValues(m,p,gp,zero,b.fixedP);
    const auto pg=detail::conservativePressureGradient(m,pf);
    Vec exactpf(nf);for(std::size_t id=0;id<nf;++id)exactpf[id]=vortex(m.faces[id].centre).p;
    const auto exactpg=detail::conservativePressureGradient(m,exactpf);
    std::cout<<std::setprecision(17)<<"{\"cells\":"<<n<<",\"faces\":"<<nf<<",\"wallStress\":{\n";
    bool comma=false;
    for(bool symmetric:{false,true}) {
        c.viscousStress=symmetric?ViscousStress2D::Symmetric:ViscousStress2D::Laplacian;
        const auto sc=symmetric?detail::symmetricViscousCorrection(m,u,v,gu,gv,b.u,b.v,b.fixedU,b.fixedV,b.constantU,b.constantV,c.nu):std::vector<Vector2D>{};
        const auto delta=quadraticWallPrototype().defect(m,c,b,u,v,gu,gv,sc);
        std::map<std::string,Stats> original,quadratic;
        for(std::size_t id=0;id<nf;++id)if(!m.faces[id].neighbour) {
            const auto& f=m.faces[id];const double length=std::hypot(f.areaVector.x,f.areaVector.y);
            const auto exact=stressFlux(vortex(f.centre),f,c.nu,symmetric);
            Vector2D old{-c.nu*(f.transmissibility*(b.u[id]-u[f.owner])+dot(gu[f.owner],f.correction)),
                         -c.nu*(f.transmissibility*(b.v[id]-v[f.owner])+dot(gv[f.owner],f.correction))};
            if(!sc.empty())old=old+sc[id];
            const auto group=std::hypot(f.centre.x,f.centre.y)<.75?"rotor":"housing";
            original[group].add((old-exact)*(1/length),length);quadratic[group].add((old+delta[id]-exact)*(1/length),length);
        }
        if(comma)std::cout<<",\n";comma=true;
        std::cout<<'"'<<(symmetric?"symmetric":"laplacian")<<"\": {";bool comma2=false;
        for(const auto& [name,s]:original){if(comma2)std::cout<<',';comma2=true;std::cout<<'"'<<name<<"\": {\"linearTractionError\":";original[name].write();std::cout<<",\"quadraticTractionError\":";quadratic[name].write();std::cout<<'}';}std::cout<<'}';
    }
    
    std::map<std::string,Stats> traceNormal,traceTangent;double minNormalDistance=1;
    std::size_t minFace=0;
    for(std::size_t id=0;id<nf;++id)if(!m.faces[id].neighbour){const auto& face=m.faces[id];const double length=std::hypot(face.areaVector.x,face.areaVector.y);const auto normal=face.areaVector*(1/length);const Vector2D tangent{-normal.y,normal.x};const auto e=vortex(face.centre);const Vector2D error{b.u[id]-e.u,b.v[id]-e.v};const auto group=std::hypot(face.centre.x,face.centre.y)<.75?"rotor":"housing";traceNormal[group].add({dot(error,normal),0},length);traceTangent[group].add({dot(error,tangent),0},length);const double dn=dot(face.centre-m.cells[face.owner].centre,normal);if(dn<minNormalDistance){minNormalDistance=dn;minFace=id;}}
    std::cout<<"},\n\"circleFieldVsPrescribedPolygonTrace\":{";bool tcomma=false;
    for(const auto& [name,s]:traceNormal){if(tcomma)std::cout<<',';tcomma=true;std::cout<<'"'<<name<<"\":{\"normalMismatch\":";traceNormal[name].write();std::cout<<",\"tangentialMismatch\":";traceTangent[name].write();std::cout<<'}';}
    std::cout<<",\"minimumWallNormalDistance\":"<<minNormalDistance<<",\"minimumDistanceFace\":"<<minFace;
    std::cout<<"},\n\"pressure\":{";
    Stats linearWallPressure,lsGradient,forceGradient,exactFaceGradient;
    for(std::size_t id=0;id<nf;++id)if(!m.faces[id].neighbour){const auto& f=m.faces[id];linearWallPressure.add({pf[id]-exactpf[id],0},std::hypot(f.areaVector.x,f.areaVector.y));}
    for(std::size_t i=0;i<n;++i){const auto analytic=vortex(m.cells[i].centre);lsGradient.add(gp[i]-analytic.gp,m.cells[i].area);forceGradient.add(pg[i]-analytic.gp,m.cells[i].area);exactFaceGradient.add(exactpg[i]-analytic.gp,m.cells[i].area);}
    std::cout<<"\"wallPressure\":";linearWallPressure.write();std::cout<<",\"leastSquaresGradient\":";lsGradient.write();std::cout<<",\"conservativeGradient\":";forceGradient.write();std::cout<<",\"exactFaceConservativeGradient\":";exactFaceGradient.write();
    // Polynomial reproduction on the ACTUAL polygon mesh: all traces are
    // smooth samples. No continuum-flow or tolerance claim is made here.
    Vec f(n),fb(nf);auto value=[](Point2D c){return 3+.7*c.x-.2*c.y+.3*c.x*c.x-.15*c.x*c.y+.4*c.y*c.y;};
    for(std::size_t i=0;i<n;++i)f[i]=value(m.cells[i].centre);
    for(std::size_t id=0;id<nf;++id)fb[id]=value(m.faces[id].centre);
    const auto gf=detail::flowGradient(m,f,fb,b.fixedU);Stats linearPoly,quadraticPoly;
    const auto& geometry=quadraticWallPrototype().prepare(m,b);
    for(std::size_t id=0;id<nf;++id)if(geometry[id]) {
        const auto& face=m.faces[id];const Vector2D exact{.7+.6*face.centre.x-.15*face.centre.y,-.2-.15*face.centre.x+.8*face.centre.y};
        const auto linear=detail::viscousFaceGradient(m,id,f,gf,fb,b.fixedU,std::vector<bool>(nf));Vector2D quadratic{};
        for(const auto& sample:geometry[id]->samples){const double x=(sample.boundary?fb[sample.index]:f[sample.index])-fb[id];quadratic.x+=sample.weight.x*x;quadratic.y+=sample.weight.y*x;}
        const double l=std::hypot(face.areaVector.x,face.areaVector.y);linearPoly.add(linear-exact,l);quadraticPoly.add(quadratic-exact,l);
    }
    std::cout<<"},\n\"quadraticPolynomialGradient\":{\"original\":";linearPoly.write();std::cout<<",\"quadratic\":";quadraticPoly.write();std::cout<<"}}\n";
    return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
