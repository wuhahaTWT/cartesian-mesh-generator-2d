#include "QuadraticWallPrototype.hpp"
namespace cartmesh2d::fv::solver_detail {
void baselineMomentum(System&,const FvMesh2D&,const FlowControls2D&,const Boundary&,const Vec&,const Vec&,
    const std::vector<Vector2D>&,const std::vector<Vector2D>&,const std::vector<Vector2D>&,
    const std::vector<Vector2D>&,const std::vector<Vector2D>&,bool,const Vec*,double);
void baselinePostprocessForces(const FvMesh2D&,const FlowControls2D&,const Boundary&,FlowResult2D&,const Vec&,
    const std::vector<Vector2D>&,const std::vector<Vector2D>&,const std::vector<Vector2D>&,const std::vector<Vector2D>&);
void momentum(System& a,const FvMesh2D& m,const FlowControls2D& c,const Boundary& b,const Vec& field,const Vec& flux,
    const std::vector<Vector2D>& gradField,const std::vector<Vector2D>& gp,const std::vector<Vector2D>& source,
    const std::vector<Vector2D>& stress,const std::vector<Vector2D>& faceVelocity,bool y,const Vec* previous,double dt) {
    baselineMomentum(a,m,c,b,field,flux,gradField,gp,source,stress,faceVelocity,y,previous,dt);
    // Research-only hook: all native callers assemble U then V before either
    // is applied/solved. Defer the complete vector wall defect until both live
    // scalar fields are available. Product design should expose an explicit
    // vector stress operator and avoid this paired-call mechanism.
    struct Pending {System* a=nullptr;const Vec* u=nullptr;const std::vector<Vector2D>* gu=nullptr;};
    static thread_local Pending pending;
    if(!y){ensure(pending.a==nullptr,"Prototype wall momentum pair did not complete");pending={&a,&field,&gradField};return;}
    ensure(pending.a!=nullptr,"Prototype wall momentum requires U before V");
    const auto delta=quadraticWallPrototype().defect(m,c,b,*pending.u,field,*pending.gu,gradField,stress);
    for(std::size_t id=0;id<m.faces.size();++id)if(!m.faces[id].neighbour) {
        pending.a->rhs[m.faces[id].owner]-=delta[id].x;a.rhs[m.faces[id].owner]-=delta[id].y;
    }
    
#ifdef QW_OWNER_RESPONSE
    const auto& geometry=quadraticWallPrototype().prepare(m,b);
    for(std::size_t id=0;id<m.faces.size();++id)if(geometry[id]) {
        const auto& f=m.faces[id];const auto i=f.owner;Vector2D weight{};
        for(const auto& sample:geometry[id]->samples)if(!sample.boundary && sample.index==i){weight.x+=sample.weight.x;weight.y+=sample.weight.y;}
        const auto normal=f.areaVector*(1/std::hypot(f.areaVector.x,f.areaVector.y));
        const auto wu=b.constantU[id]?normal*dot(weight,normal):weight;
        const auto d=b.constantV[id]?normal*dot(weight,normal):weight;
        const double nu=faceNu(c,id);double du=-nu*dot(wu,f.areaVector),dv=-nu*dot(d,f.areaVector);
        if(c.viscousStress==ViscousStress2D::Symmetric){du-=nu*wu.x*f.areaVector.x;dv-=nu*d.y*f.areaVector.y;}
        const double deltaU=du-nu*f.transmissibility,deltaV=dv-nu*f.transmissibility;
        pending.a->diag[i]+=deltaU;pending.a->rhs[i]+=deltaU*(*pending.u)[i];
        a.diag[i]+=deltaV;a.rhs[i]+=deltaV*field[i];
    }
#endif
    pending={};
}
void postprocessForces(const FvMesh2D& m,const FlowControls2D& c,const Boundary& b,FlowResult2D& r,const Vec& pb,
    const std::vector<Vector2D>& gp,const std::vector<Vector2D>& gu,const std::vector<Vector2D>& gv,const std::vector<Vector2D>& stress) {
    auto modified=quadraticWallPrototype().defect(m,c,b,r.u,r.v,gu,gv,stress);
    if(!stress.empty())for(std::size_t id=0;id<m.faces.size();++id)modified[id]=modified[id]+stress[id];
    baselinePostprocessForces(m,c,b,r,pb,gp,gu,gv,modified);
}
}
