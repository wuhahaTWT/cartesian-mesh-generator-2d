#include "QuadraticWallPrototype.hpp"
#include "cartmesh2d/fv/FlowBoundaryIO2D.hpp"
#include "cartmesh2d/io/MeshIO2D.hpp"
#include <fstream>
#include <iostream>
#include <iomanip>
using namespace cartmesh2d;using namespace cartmesh2d::fv;using namespace cartmesh2d::fv::solver_detail;
int main(int argc,char** argv){try {
    if(argc!=3)throw std::runtime_error("diagonal-audit MESH BOUNDARY");const auto input=readCm2dTopology(argv[1]);if(!input.valid())throw std::runtime_error(input.error);const auto m=makeFvMesh2D(input.topology);FlowControls2D c;c.scenario="custom";c.nu=.1;c.speed=.5;
    std::ifstream in(argv[2]);c.boundaryConditions=readFlowBoundaryConditions2D(in,m,c);const auto b=boundaries(m,c);Vec base(m.cells.size()),du(base.size()),dv(base.size());
    for(const auto& face:m.faces){const double d=c.nu*face.transmissibility;if(face.neighbour){base[face.owner]+=d;base[*face.neighbour]+=d;}else if(b.fixedU[&face-m.faces.data()])base[face.owner]+=d;}
    du=dv=base;const auto& stencils=quadraticWallPrototype().prepare(m,b);
    for(std::size_t id=0;id<m.faces.size();++id)if(stencils[id]){const auto& f=m.faces[id];Vector2D w{};for(const auto& p:stencils[id]->samples)if(!p.boundary && p.index==f.owner){w.x+=p.weight.x;w.y+=p.weight.y;}const auto normal=f.areaVector*(1/std::hypot(f.areaVector.x,f.areaVector.y));const auto wu=b.constantU[id]?normal*dot(w,normal):w,wv=b.constantV[id]?normal*dot(w,normal):w;
        du[f.owner]+=-c.nu*(dot(wu,f.areaVector)+wu.x*f.areaVector.x+f.transmissibility);
        dv[f.owner]+=-c.nu*(dot(wv,f.areaVector)+wv.y*f.areaVector.y+f.transmissibility);
    }
    std::size_t negative=0;double minimum=1e100;std::size_t worst=0;for(std::size_t i=0;i<base.size();++i){if(du[i]<=0 || dv[i]<=0)++negative;const double q=std::min(du[i],dv[i]);if(q<minimum){minimum=q;worst=i;}}
    std::cout<<std::setprecision(17)<<"{\"cells\":"<<base.size()<<",\"nonpositiveQuadraticOwnerRows\":"<<negative<<",\"minimumQuadraticOwnComponentDiagonal\":"<<minimum<<",\"worstCell\":"<<worst<<",\"baseOwnComponentDiagonal\":"<<base[worst]<<",\"quadraticUOwnComponentDiagonal\":"<<du[worst]<<",\"quadraticVOwnComponentDiagonal\":"<<dv[worst]<<",\"x\":"<<m.cells[worst].centre.x<<",\"y\":"<<m.cells[worst].centre.y<<",\"nonpositiveRows\":[";
    bool comma=false;for(std::size_t i=0;i<base.size();++i)if(du[i]<=0 || dv[i]<=0){if(comma)std::cout<<',';comma=true;std::cout<<"{\"cell\":"<<i<<",\"base\":"<<base[i]<<",\"u\":"<<du[i]<<",\"v\":"<<dv[i]<<'}';}std::cout<<"]}\n";
    return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
