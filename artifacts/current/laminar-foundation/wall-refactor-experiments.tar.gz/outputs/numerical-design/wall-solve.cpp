#include "cartmesh2d/fv/Incompressible2D.hpp"
#include "cartmesh2d/fv/FlowBoundaryIO2D.hpp"
#include "cartmesh2d/io/MeshIO2D.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <chrono>
#include <cmath>
using namespace cartmesh2d;
using namespace cartmesh2d::fv;
int main(int argc,char** argv){try {
    if(argc<6)throw std::runtime_error("wall-solve MESH BOUNDARY laplacian|symmetric coupled|simple OUTPUT [steps]");
    const auto started=std::chrono::steady_clock::now();const auto input=readCm2dTopology(argv[1]);if(!input.valid())throw std::runtime_error(input.error);
    const auto m=makeFvMesh2D(input.topology);
    FlowControls2D c;c.scenario="custom";c.nu=.1;c.speed=.5;c.tolerance=1e-8;c.maxIterations=argc>6?std::stoul(argv[6]):12000;
    c.viscousStress=std::string(argv[3])=="symmetric"?ViscousStress2D::Symmetric:ViscousStress2D::Laplacian;
    c.coupling=std::string(argv[4])=="coupled"?FlowCoupling2D::Coupled:FlowCoupling2D::Simple;
    c.convection=ConvectionScheme2D::FaceLimitedLinearUpwind;c.pressurePreconditioner=PressurePreconditioner2D::IncompleteCholesky0;c.adaptiveLinear=true;c.profile=true;
    std::ifstream boundary(argv[2]);c.boundaryConditions=readFlowBoundaryConditions2D(boundary,m,c);
    const auto r=solveIncompressible2D(m,c,[](const FlowIteration2D& h){std::cerr<<"iteration="<<h.iteration<<" momentum="<<h.momentumResidual<<" flux="<<h.fluxConsistency<<std::endl;});const auto& h=r.history.back();
    const auto exactP=[](Point2D q){constexpr double A=-1./3.,B=1./3.;const double r2=q.x*q.x+q.y*q.y;return .5*A*A*r2+A*B*std::log(r2)-.5*B*B/r2;};
    const double gauge=exactP(m.cells[0].centre);long double u2=0,p2=0,mean=0,area=0;
    std::ofstream fields(std::string(argv[5])+".cells.csv");fields<<std::setprecision(17)<<"cell,x,y,area,u,v,p,p_error\n";
    for(std::size_t i=0;i<m.cells.size();++i) {
        const auto& cell=m.cells[i];const double radius2=cell.centre.x*cell.centre.x+cell.centre.y*cell.centre.y;
        const double s=-1./3.+1./(3*radius2),ue=-cell.centre.y*s,ve=cell.centre.x*s,pe=exactP(cell.centre)-gauge,error=r.p[i]-pe;
        u2+=cell.area*((r.u[i]-ue)*(r.u[i]-ue)+(r.v[i]-ve)*(r.v[i]-ve));p2+=cell.area*error*error;mean+=cell.area*error;area+=cell.area;
        fields<<i<<','<<cell.centre.x<<','<<cell.centre.y<<','<<cell.area<<','<<r.u[i]<<','<<r.v[i]<<','<<r.p[i]<<','<<error<<'\n';
    }
    const double pmean=static_cast<double>(mean/area);const double pstdev=std::sqrt(std::max(0.,static_cast<double>(p2/area)-pmean*pmean));
    std::ofstream json(std::string(argv[5])+".json");json<<std::setprecision(17)<<"{\"converged\":"<<(r.converged?"true":"false")<<",\"cells\":"<<m.cells.size()<<",\"iterations\":"<<h.iteration<<",\"velocityL2\":"<<std::sqrt(static_cast<double>(u2/area))/c.speed<<",\"pressureL2\":"<<std::sqrt(static_cast<double>(p2/area))/(c.speed*c.speed)<<",\"pressureErrorMean\":"<<pmean/(c.speed*c.speed)<<",\"pressureMeanFreeL2\":"<<pstdev/(c.speed*c.speed)<<",\"momentumResidual\":"<<h.momentumResidual<<",\"continuity\":"<<h.continuity<<",\"fluxConsistency\":"<<h.fluxConsistency<<",\"strictLinearFinal\":"<<(h.strictLinearStep?"true":"false")<<",\"Krylov\":"<<r.performance.coupledIterations<<",\"wallSeconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()<<",\"namedWallLoads\":[";
    for(std::size_t i=0;i<r.namedWallLoads.size();++i){if(i)json<<',';const auto& load=r.namedWallLoads[i];const double torque=load.pressureTorque+load.viscousTorque;json<<"{\"name\":\""<<load.name<<"\",\"torque\":"<<torque<<",\"torqueRelativeError\":"<<std::abs(std::abs(torque)-4*M_PI*c.nu/3)/(4*M_PI*c.nu/3)<<'}';}json<<"]}\n";
    std::cout<<std::setprecision(17)<<"converged="<<r.converged<<" iterations="<<h.iteration<<" velocityL2="<<std::sqrt(static_cast<double>(u2/area))/c.speed<<" pressureL2="<<std::sqrt(static_cast<double>(p2/area))/(c.speed*c.speed)<<" pMean="<<pmean/(c.speed*c.speed)<<" pMeanFree="<<pstdev/(c.speed*c.speed)<<" failure="<<r.failureReason<<'\n';
    return r.converged?0:1;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}}
