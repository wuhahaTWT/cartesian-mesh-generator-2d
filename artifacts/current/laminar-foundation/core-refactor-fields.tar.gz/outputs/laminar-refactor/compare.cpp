#include "FvTestMesh2D.hpp"
#include "cartmesh2d/fv/Incompressible2D.hpp"
#include <bit>
#include <filesystem>
#include <fstream>
#include <iostream>
using namespace cartmesh2d::fv;
void save(const std::filesystem::path& root, const std::string& name, const FlowResult2D& result) {
    std::ofstream fields(root/(name+".bits"));
    for (const auto* values:{&result.u,&result.v,&result.p,&result.flux}) {
        for (double value:*values) fields << std::hex << std::bit_cast<std::uint64_t>(value) << '\n';
    }
    std::cout << name << ',' << result.converged << ',' << result.history.size() << ',' << result.failureReason << '\n';
}
int main(int argc,char** argv) {
    if(argc!=2)return 2;
    const std::filesystem::path root=argv[1];std::filesystem::create_directories(root);
    for(const std::string name:{"channel","warped-channel","cavity","manufactured","transient"}) {
        const auto mesh=fv_test::rectangle(12,8,name.find("channel")!=std::string::npos?2:1,name!="channel");
        FlowControls2D c;c.nu=.1;c.tolerance=1e-8;c.maxIterations=12000;c.pressurePreconditioner=PressurePreconditioner2D::IncompleteCholesky0;
        c.scenario=name=="warped-channel"?"channel":name;c.convection=ConvectionScheme2D::FaceLimitedLinearUpwind;
        if(name=="manufactured")c.manufacturedPressureSlope=.2;
        if(name=="transient") {
            c.scenario="taylor-green";const auto initial=initialIncompressibleState2D(mesh,c);
            save(root,name,advanceIncompressible2D(mesh,c,initial,.01));
        } else {
            save(root,name+"-simple",solveIncompressible2D(mesh,c));
            c.coupling=FlowCoupling2D::Coupled;c.adaptiveLinear=true;
            save(root,name+"-coupled",solveIncompressible2D(mesh,c));
        }
    }
}
