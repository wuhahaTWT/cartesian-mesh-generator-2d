# Execution record for one authorized native solve; no alternate equations.
import hashlib,json,os,pathlib,subprocess,time,resource
root=pathlib.Path('/workspace/cartesian-mesh-generator-2d');folder=root/'outputs/open-source-core/native-stokes'
command=[str(folder/'flow-cli'),'--mesh','outputs/laminar-refactor/inputs/annulus-l7.solver.cm2d','--case','custom','--boundary','outputs/laminar-refactor/inputs/annulus-l7.boundaries','--output','outputs/open-source-core/native-stokes/flow','--nu','.1','--speed','.5','--convection','face-limited-linear','--viscous-stress','symmetric','--coupling','coupled','--convergence','strict','--pressure-preconditioner','ic0','--linear-policy','adaptive','--momentum-inertia','0','--max-iterations','12000','--tolerance','1e-8','--profile']
start=time.perf_counter()
with (folder/'run.log').open('wb') as output:
    process=subprocess.Popen(command,cwd=root,stdout=output,stderr=subprocess.STDOUT)
    _,status,usage=os.wait4(process.pid,0);process.returncode=os.waitstatus_to_exitcode(status)
record={'sourceHead':'d51d8eb7dc10c395723771fd5d13f859da24f839','command':command,'binarySha256':hashlib.sha256((folder/'flow-cli').read_bytes()).hexdigest(),'returnCode':process.returncode,'wallSeconds':time.perf_counter()-start,'cpuSeconds':usage.ru_utime+usage.ru_stime,'peakRssKiB':usage.ru_maxrss,'measurement':'wait4 of this native child only; includes input read, solve and export','preflight':'First invocation could not start because /usr/bin/time is absent; no native solver ran in that preflight. Preserved time.log.'}
(folder/'run.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));raise SystemExit(process.returncode)
