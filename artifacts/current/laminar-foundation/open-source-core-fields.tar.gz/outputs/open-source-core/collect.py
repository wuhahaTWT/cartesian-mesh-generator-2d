import csv
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[2]
out = root / 'outputs/open-source-core'
artifact = root / 'artifacts/current/laminar-foundation'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(), parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))

runs = []
for metadata in sorted((out / 'final').glob('*.run.json')):
    data = read(metadata)
    assert data['status'] == 'converged'
    assert all(run['returnCode'] == 0 for run in data['runs'])
    summary = data['solution']
    assert summary['converged'] and summary['scaledResidual'] < 1e-8 and summary['scaledUpdate'] < 1e-8
    prefix = Path(str(metadata).removesuffix('.run.json'))
    rows = list(csv.DictReader(Path(str(prefix) + '.cells.csv').open()))
    assert len(rows) == data['meshMapping']['nc']
    assert all(int(row['cell']) == i and all(math.isfinite(float(v)) for v in row.values()) for i, row in enumerate(rows))
    for suffix, digest in data['fields'].items():
        assert sha(Path(str(prefix) + suffix)) == digest
    runs.append({'name': prefix.name, 'controls': data['controls'], 'mesh': data['meshMapping'],
                 'result': summary, 'commandsAndCost': data['runs'], 'metadataSha256': sha(metadata),
                 'metadata': str(metadata.relative_to(root)), 'fields': data['fields']})
assert len(runs) == 10

# Evidence only: omit runtime packages, static libraries, executables, duplicate
# generated meshes and plots. Preserve raw FV fields/fluxes and final FE fields.
members = set()
def add(path):
    if path.is_file(): members.add(path)

for directory in ['native-stokes', 'native-exact-trace', 'native-exact-trace-supported',
                  'native-exact-trace-supported-simple', 'performance', 'source-initial',
                  'adapter-checks', 'export-check']:
    for path in (out / directory).iterdir():
        if path.suffix in {'.json', '.csv', '.py', '.cpp', '.edp', '.idp', '.log', '.boundaries'}:
            add(path)
        elif directory == 'performance':
            add(path)
for path in (out / 'final').iterdir():
    if '-input.' in path.name:
        if path.name.endswith('.mapping.json'): add(path)
    elif path.suffix in {'.json', '.csv', '.log'}:
        add(path)
    elif path.name in {'cr-l7-ns.fe-solution.txt', 'th-l7-exact-ns.fe-solution.txt'}:
        add(path)
for path in out.iterdir():
    if path.suffix in {'.json', '.py', '.log'}: add(path)
for name in ['cr-l5-stokes.fe-solution.txt', 'cr-l6-stokes.fe-solution.txt']:
    add(out / name)
for name in ['annulus-l5-original-symmetric.cells.csv', 'annulus-l6-original-symmetric.cells.csv',
             'annulus-l7-original-symmetric.cells.csv']:
    add(root / 'outputs/numerical-design' / name)

archive = artifact / 'open-source-core-fields.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=9) as tar:
    for path in sorted(members): tar.add(path, arcname=str(path.relative_to(root)), recursive=False)

source = [root / 'CMakeLists.txt'] + list((root / 'tools/benchmarks').glob('freefem_*'))
record = {
    'format': 'cartmesh2d-native-freefem-reference-v1',
    'sourceBase': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'sourceQualifier': 'Uncommitted adapter snapshot at execution; numerical source hashes below and per-run metadata identify the actual code. Product FV numerical code unchanged from sourceBase.',
    'sourceSha256': {str(p.relative_to(root)): sha(p) for p in source if p.is_file()},
    'dependency': read(out / 'dependency-provenance.json'),
    'originalInputArchive': {'path': 'artifacts/current/laminar-foundation/failure-inputs.tar.gz',
                             'sha256': sha(artifact / 'failure-inputs.tar.gz')},
    'finalExternalRuns': runs,
    'nativeStokes': read(out / 'native-stokes/evaluation.json'),
    'nativeExactTrace': read(out / 'native-exact-trace-supported/summary.json'),
    'nativeExactTraceSimpleFailure': read(out / 'native-exact-trace-supported-simple/summary.json'),
    'pressureGaugeDiagnostic': read(out / 'pressure-gauge.json'),
    'comparisonControls': read(out / 'comparison-controls.json'),
    'sparsePressureGauge': read(out / 'performance/summary.json'),
    'stoppedInitialMeanConstraintRuns': read(out / 'mean-constraint-stopped.json'),
    'checks': {'exporterBuild': 'passed', 'originalMeshesByteUnchangedAfterBenchmarkChecks': read(out / 'export-check/checks.json'),
               'adapter': read(out / 'adapter-checks/summary.json'), 'finiteMappedFieldsAndRecordedHashes': 'all ten final runs passed',
               'productRegression': 'No FV numerical code changed in this increment. Full CTest/frontend/App/platform CI not rerun; prior refactor checks are recorded separately.'},
    'findings': [
        'Native FreeFEM CR/P0 on retained 484/1672/6208-cell polygons converged in 2 Stokes / 4 NS Newton steps with original prescribed face means.',
        'The finest case has 24836 triangles, 100328 CR/P0 DOFs; this is an actual 2D mesh, not an extruded 3D solver.',
        'Taylor-Hood symmetric-stress exact-trace NS controls converged in 3 steps at all three levels; finest mean-free pressure L2/Uref^2 is 7.734316580124876e-5.',
        'Native coupled with exact sampled trace/changed boundary roles passes in 10 steps; same supported trace under SIMPLE diverges, last report at 100 steps, then linear iteration-limit exception.',
        'Removing inertia retains almost the same native pressure error pattern. Gauge removal accounts for only about 0.5% of the original finest pressure-error square.',
        'Boundary/trace/role treatment contributes substantially to pressure diagnostics; SIMPLE iteration instability is distinct. The unique defective coefficient and a general product fix are not established.'
    ],
    'limits': [
        'CR uses broken Laplacian and edge-average continuity; TH uses continuous P2/P1 and symmetric stress. Neither is the same finite-grid FV operator.',
        'Original facet boundary velocities jump at polygon corners. CR fixes their means, not pointwise impermeability. TH exact trace changes the physical boundary and includes local normal velocity.',
        'FE weak residual normalization is not the FV strict residual norm, and convergence does not certify spatial accuracy.',
        'FE mapped values are exact triangle-quadrature polygon means; FV output values are centroid estimates. Analytic native trace also changes boundary reconstruction roles.',
        'Three existing levels change both polygon approximation and interior discretization; no isolated fixed-geometry convergence order or universal timing claim is made.',
        'DFG, general boundary types, default App integration, cross-platform execution and high-density scaling remain untested for this external adapter.'
    ],
    'initialAdapterFailure': {
        'cause': 'FreeFEM also exposes artificial region interfaces in Th.be; initially treating every Th.be label as a physical Dirichlet boundary incorrectly constrained internal edges.',
        'fix': 'Use only explicit input boundary kind/face labels, leaving all region interfaces free.',
        'evidence': 'cr-l5-debug.log and initial failed attempts are retained. The source-initial snapshot is the corrected mean-constraint implementation; it is not claimed to reproduce the earlier bad-label code.'
    },
    'archive': {'path': str(archive.relative_to(root)), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
                'members': len(members), 'retention': 'Native fields/fluxes, all final FE cell means, representative fine FE coefficients, logs, controls, failures, original research drivers. Runtime packages and generated mesh duplicates stay local and are reproducible.'}
}
(artifact / 'open-source-core.json').write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'cases': len(runs), 'archiveBytes': archive.stat().st_size, 'archiveMembers': len(members)}, indent=2))
