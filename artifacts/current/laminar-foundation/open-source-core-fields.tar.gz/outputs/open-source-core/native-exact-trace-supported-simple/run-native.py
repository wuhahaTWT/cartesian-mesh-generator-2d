# One unmodified native SIMPLE solve, with externally retained progress on API throws.
import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/cartesian-mesh-generator-2d')
folder=root/'outputs/open-source-core/native-exact-trace-supported-simple'
libraries=root/'outputs/open-source-core/native-exact-trace'
mesh=root/'outputs/laminar-refactor/inputs/annulus-l7.solver.cm2d'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
command=[str(folder/'exact-trace'),str(mesh),str(folder/'ns-simple'),'1','simple']
started=time.perf_counter()
with (folder/'ns-simple.run.log').open('wb') as output:
    child=subprocess.Popen(command,cwd=root,stdout=output,stderr=subprocess.STDOUT)
    _,status,usage=os.wait4(child.pid,0)
    child.returncode=os.waitstatus_to_exitcode(status)
record={'nativeLibrarySourceHead':'d51d8eb7dc10c395723771fd5d13f859da24f839','command':command,'returnCode':child.returncode,'wallSeconds':time.perf_counter()-started,'cpuSeconds':usage.ru_utime+usage.ru_stime,'peakRssKiB':usage.ru_maxrss,'measurement':'wait4 of this native child; includes mesh read, solve and export','sha256':{str(path.relative_to(root)):sha(path) for path in (folder/'exact-trace.cpp',folder/'exact-trace',libraries/'libcartmesh2d_fv.a',libraries/'libcartmesh2d.a',mesh)},'controls':{'coupling':'simple','momentumInertia':1,'nu':.1,'speed':.5,'tolerance':1e-8,'maxIterations':1000,'viscousStress':'symmetric','convection':'face-limited-linear','pressurePreconditioner':'ic0','adaptiveLinear':True,'velocityRelaxation':.6,'pressureRelaxation':.25,'pressureCorrectionPasses':4,'cooperativeBudgetSeconds':120},'qualification':'Exactly one q==0, U!=0 face uses unchanged SmoothMovingWall; other 983 faces use generic velocity inlet/outlet by exact unadjusted q sign. No role/sign/conservation checks were changed.'}
(folder/'ns-simple.run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(child.returncode)
