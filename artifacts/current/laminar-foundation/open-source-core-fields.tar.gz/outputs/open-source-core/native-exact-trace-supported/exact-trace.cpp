#include "cartmesh2d/fv/Incompressible2D.hpp"
#include "cartmesh2d/fv/FlowBoundaryIO2D.hpp"
#include "cartmesh2d/io/MeshIO2D.hpp"
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>

using namespace cartmesh2d;
using namespace cartmesh2d::fv;

static Vector2D exactU(Point2D q) {
    const double r2=q.x*q.x+q.y*q.y;
    const double s=-1./3.+1./(3*r2);
    return {-q.y*s,q.x*s};
}
static double exactP(Point2D q,double inertia) {
    const double r2=q.x*q.x+q.y*q.y;
    return inertia*(r2/18-std::log(r2)/9-1/(18*r2));
}
static std::string quote(const std::string& value) {
    std::ostringstream out;out<<'"';
    for(unsigned char ch:value) {
        if(ch=='"'||ch=='\\')out<<'\\'<<ch;
        else if(ch=='\n')out<<"\\n";
        else if(ch=='\r')out<<"\\r";
        else if(ch=='\t')out<<"\\t";
        else if(ch<32)out<<"\\u"<<std::hex<<std::setw(4)<<std::setfill('0')<<unsigned(ch)<<std::dec;
        else out<<ch;
    }
    return out.str()+'"';
}
int main(int argc,char** argv) {
    std::string prefix,phase="arguments";
    try {
        if(argc!=4)throw std::runtime_error("exact-trace MESH OUTPUT_PREFIX INERTIA_0_OR_1");
        prefix=argv[2];const double inertia=std::stod(argv[3]);
        if(inertia!=0&&inertia!=1)throw std::runtime_error("inertia must be exactly 0 or 1");
        phase="mesh";
        const auto input=readCm2dTopology(argv[1]);
        if(!input.valid())throw std::runtime_error(input.error);
        const auto mesh=makeFvMesh2D(input.topology);
        FlowControls2D c;c.scenario="custom";c.nu=.1;c.speed=.5;c.tolerance=1e-8;
        c.maxIterations=12000;c.viscousStress=ViscousStress2D::Symmetric;
        c.convection=ConvectionScheme2D::FaceLimitedLinearUpwind;
        c.coupling=FlowCoupling2D::Coupled;c.convergence=FlowConvergence2D::Strict;
        c.pressurePreconditioner=PressurePreconditioner2D::IncompleteCholesky0;
        c.adaptiveLinear=true;c.profile=true;c.momentumInertia=inertia;
        double flux=0,absoluteFlux=0;long double wideFlux=0;
        std::size_t inward=0,outward=0,zero=0,zeroNonzeroVelocity=0;
        std::ofstream bc(prefix+".matchedBC.csv");
        bc<<std::setprecision(17)<<"face,owner,x,y,Sx,Sy,u,v,flux,kind,name\n";
        for(std::size_t id=0;id<mesh.faces.size();++id) {
            const auto& f=mesh.faces[id];if(f.neighbour)continue;
            const auto u=exactU(f.centre);const double q=dot(u,f.areaVector);
            const std::string region=std::hypot(f.centre.x,f.centre.y)<.75?"rotor":"housing";
            FlowBoundaryKind2D kind;
            if(q<0){kind=FlowBoundaryKind2D::VelocityInlet;++inward;}
            else if(q>0){kind=FlowBoundaryKind2D::VelocityOutlet;++outward;}
            else {
                ++zero;
                if(u.x==0&&u.y==0)kind=FlowBoundaryKind2D::Wall;
                // Authorized supported control: retain exactly the same analytic
                // trace on the one q==0 face through the existing smooth wall BC.
                // Its tangential-gradient path remains wall-specific.
                else {kind=FlowBoundaryKind2D::SmoothMovingWall;++zeroNonzeroVelocity;}
            }
            const std::string name=region+"-"+flowBoundaryKindName2D(kind);
            c.boundaryConditions.push_back({id,kind,u,0,name});
            flux+=q;absoluteFlux+=std::abs(q);wideFlux+=q;
            bc<<id<<','<<f.owner<<','<<f.centre.x<<','<<f.centre.y<<','<<f.areaVector.x<<','<<f.areaVector.y<<','<<u.x<<','<<u.y<<','<<q<<','<<flowBoundaryKindName2D(kind)<<','<<name<<'\n';
        }
        bc.close();
        std::ofstream audit(prefix+".boundary-audit.json");
        audit<<std::setprecision(17)<<"{\"cells\":"<<mesh.cells.size()<<",\"faces\":"<<mesh.faces.size()<<",\"boundaryFaces\":"<<c.boundaryConditions.size()<<",\"inward\":"<<inward<<",\"outward\":"<<outward<<",\"zero\":"<<zero<<",\"zeroWithNonzeroVelocity\":"<<zeroNonzeroVelocity<<",\"zeroNonzeroVelocityKind\":\"smooth-moving-wall\",\"zeroFaceQualification\":\"original analytic velocity retained; this one exactly zero-flux face uses the existing wall-specific tangential-gradient path\",\"prescribedFlux\":"<<flux<<",\"prescribedFluxWideAccumulation\":"<<static_cast<double>(wideFlux)<<",\"prescribedFluxMagnitude\":"<<absoluteFlux<<",\"originalNetFluxTolerance\":"<<TolerancePolicy{}.scale(absoluteFlux)<<",\"netFluxWithinOriginalTolerance\":"<<(std::abs(flux)<=TolerancePolicy{}.scale(absoluteFlux)?"true":"false")<<",\"fluxAdjustment\":0,\"pressureBoundaryFaces\":0,\"trace\":\"full circular Couette velocity evaluated at every actual polygon face centre; changes the impermeable facet-wall problem\"}\n";
        audit.close();
        phase="boundary-validation";
        validateFlowBoundaryConditions2D(mesh,c);
        std::ofstream boundary(prefix+".boundaries");writeFlowBoundaryConditions2D(boundary,mesh,c);boundary.close();
        phase="solve";
        const auto started=std::chrono::steady_clock::now();
        // Explicit experiment budget preserves the last accepted native iterate.
        c.stopRequested=[&] {return std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()>120;};
        const auto r=solveIncompressible2D(mesh,c,[](const FlowIteration2D& h) {
            std::cerr<<std::setprecision(17)<<"iteration="<<h.iteration<<" momentum="<<h.momentumResidual<<" continuity="<<h.continuity<<" fluxConsistency="<<h.fluxConsistency<<" strictLinear="<<h.strictLinearStep<<'\n';
        });
        phase="export";
        const double wall=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
        long double area=0,u2=0,p2=0,pmean=0,speed2=0;double pmin=std::numeric_limits<double>::infinity(),pmax=-pmin,umax=0;
        const double gauge=exactP(mesh.cells[0].centre,inertia);
        std::ofstream fields(prefix+".cells.csv");fields<<std::setprecision(17)<<"cell,x,y,area,u,v,p,u_exact,v_exact,p_exact,p_error\n";
        for(std::size_t i=0;i<mesh.cells.size();++i) {
            const auto& cell=mesh.cells[i];const auto ue=exactU(cell.centre);const double pe=exactP(cell.centre,inertia)-gauge,e=r.p[i]-pe;
            area+=cell.area;u2+=cell.area*((r.u[i]-ue.x)*(r.u[i]-ue.x)+(r.v[i]-ue.y)*(r.v[i]-ue.y));
            p2+=cell.area*e*e;pmean+=cell.area*e;speed2+=cell.area*(r.u[i]*r.u[i]+r.v[i]*r.v[i]);
            pmin=std::min(pmin,r.p[i]);pmax=std::max(pmax,r.p[i]);umax=std::max(umax,std::hypot(r.u[i],r.v[i]));
            fields<<i<<','<<cell.centre.x<<','<<cell.centre.y<<','<<cell.area<<','<<r.u[i]<<','<<r.v[i]<<','<<r.p[i]<<','<<ue.x<<','<<ue.y<<','<<pe<<','<<e<<'\n';
        }
        std::ofstream faces(prefix+".faces.csv");faces<<std::setprecision(17)<<"face,owner,neighbour,flux\n";
        for(std::size_t i=0;i<mesh.faces.size();++i)faces<<i<<','<<mesh.faces[i].owner<<','<<(mesh.faces[i].neighbour?std::to_string(*mesh.faces[i].neighbour):"-1")<<','<<r.flux[i]<<'\n';
        std::ofstream history(prefix+".residuals.csv");history<<std::setprecision(17)<<"iteration,momentumResidual,continuity,fluxConsistency,coupledLinearResidual,strictLinearStep,lineSearchWeight\n";
        for(const auto& h:r.history)history<<h.iteration<<','<<h.momentumResidual<<','<<h.continuity<<','<<h.fluxConsistency<<','<<h.coupledLinearResidual<<','<<h.strictLinearStep<<','<<h.lineSearchWeight<<'\n';
        const auto& h=r.history.back();const double mean=static_cast<double>(pmean/area);
        std::ofstream json(prefix+".json");json<<std::setprecision(17)<<"{\"converged\":"<<(r.converged?"true":"false")<<",\"stopped\":"<<(r.stopped?"true":"false")<<",\"failureReason\":"<<quote(r.failureReason)<<",\"inertia\":"<<inertia<<",\"nu\":0.1,\"Uref\":0.5,\"convection\":\"face-limited-linear\",\"viscousStress\":\"symmetric\",\"coupling\":\"coupled\",\"convergence\":\"strict\",\"tolerance\":1e-8,\"pressurePreconditioner\":\"ic0\",\"linearPolicy\":\"adaptive\",\"pressureGaugeCell\":0,\"pressureAtGaugeCell\":"<<r.p[0]<<",\"iterations\":"<<h.iteration<<",\"momentumResidual\":"<<h.momentumResidual<<",\"continuity\":"<<h.continuity<<",\"fluxConsistency\":"<<h.fluxConsistency<<",\"strictLinearFinal\":"<<(h.strictLinearStep?"true":"false")<<",\"coupledLinearResidual\":"<<h.coupledLinearResidual<<",\"Krylov\":"<<r.performance.coupledIterations<<",\"velocityL2OverUref\":"<<std::sqrt(static_cast<double>(u2/area))/.5<<",\"pressureL2OverUrefSquared\":"<<std::sqrt(static_cast<double>(p2/area))/.25<<",\"pressureErrorMean\":"<<mean<<",\"pressureMeanFreeL2OverUrefSquared\":"<<std::sqrt(std::max(0.,static_cast<double>(p2/area)-mean*mean))/.25<<",\"speedMax\":"<<umax<<",\"speedAreaRms\":"<<std::sqrt(static_cast<double>(speed2/area))<<",\"pressureMin\":"<<pmin<<",\"pressureMax\":"<<pmax<<",\"globalImbalance\":"<<r.globalImbalance<<",\"globalRelativeImbalance\":"<<r.globalRelativeImbalance<<",\"solveWallSeconds\":"<<wall<<",\"cooperativeBudgetSeconds\":120,\"pressureReference\":\"constant for Stokes; analytic circular Couette pressure restricted to polygon for NS; face-centre sampled velocity is a midpoint boundary approximation\"}\n";
        std::cout<<"converged="<<r.converged<<" stopped="<<r.stopped<<" failure="<<r.failureReason<<" iterations="<<h.iteration<<"\n";
        return r.converged?0:1;
    }catch(const std::exception& e) {
        std::cerr<<"phase="<<phase<<" error="<<e.what()<<'\n';
        if(!prefix.empty()) {
            std::ofstream json(prefix+".rejection.json");json<<"{\"converged\":false,\"solverRan\":"<<(phase=="solve"||phase=="export"?"true":"false")<<",\"phase\":"<<quote(phase)<<",\"reason\":"<<quote(e.what())<<"}\n";
        }
        return 2;
    }
}
