# Postprocess saved fields and boundary samples; no reconstructed equations.
import csv,hashlib,json,math,pathlib,shlex
root=pathlib.Path('/workspace/cartesian-mesh-generator-2d')
folder=root/'outputs/open-source-core/native-exact-trace-supported'
read=lambda p:list(csv.DictReader(p.open()))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=root/'outputs/open-source-core/native-exact-trace'
bc=read(folder/'stokes.matchedBC.csv')
oldbc=read(old/'stokes.matchedBC.csv')
sample_columns=('face','owner','x','y','Sx','Sy','u','v','flux')
assert len(bc)==len(oldbc)==984
assert all(all(a[k]==b[k] for k in sample_columns) for a,b in zip(bc,oldbc))
assert sha(folder/'stokes.matchedBC.csv')==sha(folder/'ns.matchedBC.csv')
original_bc={}
for line in (root/'outputs/laminar-refactor/inputs/annulus-l7.boundaries').read_text().splitlines():
    values=shlex.split(line)
    if values[0]=='BOUNDARY':
        original_bc[int(values[1])]=(float(values[9]),float(values[10]))
boundary_differences={}
for group in ('rotor','housing'):
    rows=[r for r in bc if r['name'].startswith(group)]
    length=math.fsum(math.hypot(float(r['Sx']),float(r['Sy'])) for r in rows)
    normal2=tangent2=total2=0.
    for r in rows:
        sx,sy=float(r['Sx']),float(r['Sy']);s=math.hypot(sx,sy)
        orig=original_bc[int(r['face'])]
        du,dv=float(r['u'])-orig[0],float(r['v'])-orig[1]
        normal2+=s*((du*sx+dv*sy)/s)**2
        tangent2+=s*((du*(-sy)+dv*sx)/s)**2
        total2+=s*(du*du+dv*dv)
    boundary_differences[group]={'faces':len(rows),'length':length,'lengthWeightedNormalTraceDifferenceRms':math.sqrt(normal2/length),'lengthWeightedTangentialTraceDifferenceRms':math.sqrt(tangent2/length),'lengthWeightedFullTraceDifferenceRms':math.sqrt(total2/length)}

def metrics(path,inertia):
    rows=read(path);a=math.fsum(float(r['area']) for r in rows)
    def exactp(r):
        r2=float(r['x'])**2+float(r['y'])**2
        return inertia*(r2/18-math.log(r2)/9-1/(18*r2))
    gauge=exactp(rows[0]);p_errors=[];u_errors=[]
    for r in rows:
        x,y=float(r['x']),float(r['y']);s=-1/3+1/(3*(x*x+y*y))
        p_errors.append(float(r['p'])-(exactp(r)-gauge))
        u_errors.append((float(r['u'])+y*s)**2+(float(r['v'])-x*s)**2)
    mean=math.fsum(float(r['area'])*e for r,e in zip(rows,p_errors))/a
    p2=math.fsum(float(r['area'])*e*e for r,e in zip(rows,p_errors))/a
    centred=math.fsum(float(r['area'])*(e-mean)**2 for r,e in zip(rows,p_errors))/a
    u2=math.fsum(float(r['area'])*e for r,e in zip(rows,u_errors))/a
    worst=max(range(len(rows)),key=lambda i:abs(p_errors[i]))
    return {'path':str(path.relative_to(root)),'sha256':sha(path),'cells':len(rows),'velocityL2OverUref':math.sqrt(u2)/.5,'pressureL2OverUrefSquared':math.sqrt(p2)/.25,'pressureMeanFreeL2OverUrefSquared':math.sqrt(centred)/.25,'areaMeanPressureError':mean,'maximumAbsolutePressureError':abs(p_errors[worst]),'maximumPressureErrorCell':int(rows[worst]['cell']),'maximumPressureErrorCellCentre':[float(rows[worst]['x']),float(rows[worst]['y'])]}

results={}
for name,inertia in (('stokes',0),('ns',1)):
    native=json.loads((folder/(name+'.json')).read_text())
    post=metrics(folder/(name+'.cells.csv'),inertia)
    for first,second in (('velocityL2OverUref','velocityL2OverUref'),('pressureL2OverUrefSquared','pressureL2OverUrefSquared'),('pressureMeanFreeL2OverUrefSquared','pressureMeanFreeL2OverUrefSquared')):
        assert math.isclose(post[first],native[second],rel_tol=1e-11,abs_tol=1e-14)
    results[name]={'nativeResult':native,'independentFieldPostprocess':post,'execution':json.loads((folder/(name+'.run.json')).read_text())}
baseline={
    'originalFacetStokes':metrics(root/'outputs/open-source-core/native-stokes/flow.cells.csv',0),
    'originalFacetNS':metrics(root/'outputs/laminar-refactor/final/failures/annulus-l7-coupled.cells.csv',1)
}
ratios={'stokesOriginalFacetDiagnosticPressureMeanFreeRmsDividedByExactTraceControl':baseline['originalFacetStokes']['pressureMeanFreeL2OverUrefSquared']/results['stokes']['independentFieldPostprocess']['pressureMeanFreeL2OverUrefSquared'],'nsOriginalFacetCirclePressureErrorMeanFreeDividedByExactTraceControl':baseline['originalFacetNS']['pressureMeanFreeL2OverUrefSquared']/results['ns']['independentFieldPostprocess']['pressureMeanFreeL2OverUrefSquared']}
summary={'status':'Both native Stokes and NS strictly converged; prior rejected attempt preserved separately','comparisonControls':{'mesh':'same 6208 final polygon cells','nu':.1,'Uref':.5,'viscousStress':'symmetric','coupling':'coupled','convection':'face-limited-linear','tolerance':1e-8,'convergence':'strict','pressurePreconditioner':'ic0','linearPolicy':'adaptive','pressureGauge':'cell 0 only; no prescribed pressure boundary','boundarySamplesIdenticalToRejectedAttempt':True,'stokesAndNsMatchedBcByteIdentical':True,'fluxCorrection':0,'boundaryDifferencesVersusOriginalFacet':boundary_differences,'zeroFluxSmoothMovingWallFaceIds':[int(r['face']) for r in bc if r['kind']=='smooth-moving-wall']},'boundaryAudit':json.loads((folder/'stokes.boundary-audit.json').read_text()),'results':results,'sameMeshOriginalFacetDiagnostics':baseline,'diagnosticMagnitudeRatios':ratios,'claimsAndLimits':['An unmodified native API can solve this supported full analytic face-centre trace at strict tolerance for Stokes and NS.','Pressure magnitude/error is much smaller than in the original impermeable facet-tangent boundary problem.','Changing the actual velocity trace and the boundary stencil role together does not isolate a wall-specific discretization bug.','One exactly zero-flux face still uses SmoothMovingWall and therefore retains the wall-specific tangential-gradient path.','The circle Couette field restricted to the polygon is a continuous exact-domain solution only with the complete continuous analytic trace; native face-centre prescribed samples approximate this trace by midpoint data.','Original facet-tangent trace differs physically, particularly by its imposed pointwise impermeability; its circular-reference pressure diagnostic is not an exact polygon-solution error.','FE imposed interpolated trace and native midpoint samples must retain separate conservation and trace-approximation controls.','A single 6208 control does not establish mesh convergence or default solver qualification.'],'reproduction':{'compile':'c++ -std=c++20 -O2 -Iinclude outputs/open-source-core/native-exact-trace-supported/exact-trace.cpp outputs/open-source-core/native-exact-trace/libcartmesh2d_fv.a outputs/open-source-core/native-exact-trace/libcartmesh2d.a -o outputs/open-source-core/native-exact-trace-supported/exact-trace','run':'python3 outputs/open-source-core/native-exact-trace-supported/run-native.py','analyse':'python3 outputs/open-source-core/native-exact-trace-supported/analyse.py'},'manifest':json.loads((folder/'manifest.json').read_text()),'sha256':{p.name:sha(p) for p in folder.iterdir() if p.is_file() and p.name!='summary.json'}}
(folder/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'results':{n:r['independentFieldPostprocess'] for n,r in results.items()},'boundaryDifferences':boundary_differences,'ratios':ratios},indent=2))
