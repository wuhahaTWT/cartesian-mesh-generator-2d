# Calls and measures the original native solver driver; contains no alternate equations.
import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/cartesian-mesh-generator-2d')
folder=root/'outputs/open-source-core/native-exact-trace-supported'
libraries=root/'outputs/open-source-core/native-exact-trace'
mesh=root/'outputs/laminar-refactor/inputs/annulus-l7.solver.cm2d'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
records=[]
for inertia in (0,1):
    name='stokes' if inertia==0 else 'ns'
    prefix=folder/name
    command=[str(folder/'exact-trace'),str(mesh),str(prefix),str(inertia)]
    started=time.perf_counter()
    with (folder/(name+'.run.log')).open('wb') as output:
        child=subprocess.Popen(command,cwd=root,stdout=output,stderr=subprocess.STDOUT)
        _,status,usage=os.wait4(child.pid,0)
        child.returncode=os.waitstatus_to_exitcode(status)
    record={'command':command,'returnCode':child.returncode,'wallSeconds':time.perf_counter()-started,'cpuSeconds':usage.ru_utime+usage.ru_stime,'peakRssKiB':usage.ru_maxrss,'measurement':'wait4 of this native child; includes mesh read, solve and export'}
    records.append(record)
    print(json.dumps(record),flush=True)
    (folder/(name+'.run.json')).write_text(json.dumps(record,indent=2)+'\n')
    if child.returncode:
        break
manifest={'nativeLibrarySourceHead':'d51d8eb7dc10c395723771fd5d13f859da24f839','driverBuildHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sha256':{str(path.relative_to(root)):sha(path) for path in (folder/'exact-trace.cpp',folder/'exact-trace',libraries/'libcartmesh2d_fv.a',libraries/'libcartmesh2d.a',mesh)},'runs':records,'qualification':'NS runs only if Stokes converges. Exactly one q==0, U!=0 face uses the already supported SmoothMovingWall with the unmodified analytic velocity, retaining one wall-specific gradient path. All other 983 boundary faces use VelocityInlet/VelocityOutlet by original exact sign. No boundary flux adjustment or relaxed role/sign/conservation/convergence checks. Original moving-facet problem and this full analytic trace problem differ.'}
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
raise SystemExit(records[-1]['returnCode'])
