#!/usr/bin/env python3
# Existing native converged-field postprocessing only. No PDE assembly, solve,
# or alternate equation/acceptance chain. Formula is laminar.py's annulus score.
import csv, hashlib, json, math
from pathlib import Path
root=Path('/workspace/cartesian-mesh-generator-2d')
files=[('native-l5',root/'outputs/numerical-design/annulus-l5-original-symmetric.cells.csv'),('native-l6',root/'outputs/numerical-design/annulus-l6-original-symmetric.cells.csv'),('native-l7',root/'outputs/numerical-design/annulus-l7-original-symmetric.cells.csv'),('root-final-l7',root/'outputs/laminar-refactor/final/failures/annulus-l7-coupled.cells.csv')]
def p_exact(x,y):
    rr=x*x+y*y
    return rr/18-math.log(rr)/9-1/(18*rr)
def evaluate(name,path):
    with path.open() as stream:rows=list(csv.DictReader(stream))
    rows=[{k:float(v) for k,v in row.items()} for row in rows]
    area=math.fsum(row['area'] for row in rows);pg=p_exact(rows[0]['x'],rows[0]['y']);weight=lambda row:row['area']/area
    errors=[row['p']-p_exact(row['x'],row['y'])+pg for row in rows]
    mean=math.fsum(weight(row)*error for row,error in zip(rows,errors))
    rms=math.sqrt(math.fsum(weight(row)*error*error for row,error in zip(rows,errors)))
    centered=math.sqrt(math.fsum(weight(row)*(error-mean)**2 for row,error in zip(rows,errors)))
    pm=math.fsum(weight(row)*row['p'] for row in rows)
    uv2=[]
    for row in rows:
        rr=row['x']**2+row['y']**2;s=(-1+1/rr)/3
        uv2.append((row['u']+row['y']*s)**2+(row['v']-row['x']*s)**2)
    return dict(name=name,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),cells=len(rows),fluidArea=area,firstCell={k:rows[0][k] for k in ('cell','x','y','p')},pressureL2OverUrefSquared=rms/.25,areaMeanPressureErrorOverUrefSquared=mean/.25,meanFreePressureL2OverUrefSquared=centered/.25,pressureSquaredErrorFractionRemovedByBestConstant=mean*mean/(rms*rms),pressureMax=max(r['p'] for r in rows),pressureMin=min(r['p'] for r in rows),pressureMean=pm,pressureMeanFreeRms=math.sqrt(math.fsum(weight(row)*(row['p']-pm)**2 for row in rows)),velocityL2OverUref=math.sqrt(math.fsum(weight(row)*e for row,e in zip(rows,uv2)))/.5)
result=dict(scope='Postprocess retained converged native fields; no equation reconstruction or new solve.',definition='A=-1/3, B=1/3; p_exact=.5*A^2*r^2+2*A*B*log(r)-.5*B^2/r^2. Original gauge subtracts exact p at first native cell; mean-free L2 removes area-weighted pressure-error constant. Uref=.5.',fields=[evaluate(name,path) for name,path in files],conclusion='Removing the best constant leaves almost all pressure-error variance; reference-cell pressure gauge offset is not the main retained annulus pressure error.',qualification='Circle exact solution is the established laminar benchmark reference, not an exact solution on each polygon wall; gauge decomposition alone does not locate a discretization root cause.')
out=root/'outputs/open-source-core/pressure-gauge.json';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
