#include "FlowSolverDetail2D.hpp"
#include "cartmesh2d/fv/FlowBoundaryIO2D.hpp"
#include "cartmesh2d/io/MeshIO2D.hpp"
#include <array>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace cartmesh2d;
using namespace cartmesh2d::fv;
using namespace cartmesh2d::fv::solver_detail;
int main(int argc,char** argv) {try {
    ensure(argc==7,"rc_terms MESH BC pressure.txt nu speed OUTPUT");
    const auto input=readCm2dTopology(argv[1]);ensure(input.valid(),"invalid mesh");
    const auto m=makeFvMesh2D(input.topology);const auto n=m.cells.size(),nf=m.faces.size();
    FlowControls2D c;c.scenario="custom";c.nu=std::stod(argv[4]);c.speed=std::stod(argv[5]);
    c.velocityRelaxation=1;c.momentumInertia=0;
    std::ifstream bc(argv[2]);c.boundaryConditions=readFlowBoundaryConditions2D(bc,m,c);
    auto b=boundaries(m,c);std::fill(b.u.begin(),b.u.end(),0);std::fill(b.v.begin(),b.v.end(),0);
    Vec p(n),z(n),zf(nf),ra(n),df(nf);std::ifstream pin(argv[3]);
    for(auto& x:p)ensure(bool(pin>>x),"pressure vector size mismatch");
    std::vector<Vector2D> zg(n);std::vector<std::pair<std::size_t,std::size_t>> links;
    for(const auto& f:m.faces)if(f.neighbour)links.emplace_back(f.owner,*f.neighbour);
    detail::SparsePattern2D pattern(n,links);System a(pattern),v(pattern);
    momentum(a,m,c,b,z,zf,zg,zg,{}, {},{},false,nullptr,0);
    momentum(v,m,c,b,z,zf,zg,zg,{}, {},{},true,nullptr,0);
    for(std::size_t i=0;i<n;++i)ra[i]=m.cells[i].area/std::max(a.diag[i],v.diag[i]);
    const auto L=detail::buildFlowGradientStencil2D(m,b.fixedP,true).apply(p,zf);
    const auto G=detail::conservativePressureGradient(m,detail::pressureFaceValues(m,p,L,zf,b.fixedP));
    FlowResult2D state;state.u=z;state.v=z;state.p=p;state.flux=zf;
    const auto q=rhieChowFlux(m,c,b,state,ra,z,z,zg,zg,zg,zg,L,G,zf,false,0,df);
    std::ofstream faces(std::string(argv[6])+".faces.csv");
    faces<<std::setprecision(17)<<"face,angleDegrees,base,mismatchedGradients,coefficientCovariance,native,reconstructionError\n";
    std::array<long double,5> energies{},fluxSquared{};double maximumError=0,maximum=0;
    for(std::size_t id=0;id<nf;++id) {
        const auto& f=m.faces[id];if(!f.neighbour)continue;
        const auto i=f.owner,j=*f.neighbour;const double w=f.neighbourWeight,rf=interpolate(f,ra);
        const auto d=m.cells[j].centre-m.cells[i].centre,Lbar=interpolateGradient(f,L);
        const double dp=p[j]-p[i];
        const Vector2D gi{G[i].x-L[i].x,G[i].y-L[i].y},gj{G[j].x-L[j].x,G[j].y-L[j].y};
        const double base=-rf*f.transmissibility*(dp-dot(Lbar,d));
        const Vector2D mismatchGradient{(1-w)*ra[i]*gi.x+w*ra[j]*gj.x,(1-w)*ra[i]*gi.y+w*ra[j]*gj.y};
        const double mismatch=dot(mismatchGradient,f.areaVector);
        const double covariance=w*(1-w)*(ra[i]-ra[j])*dot(Vector2D{L[i].x-L[j].x,L[i].y-L[j].y},f.areaVector);
        const double projected=base*dot(f.areaVector,d)*dot(f.areaVector,d)/(squaredNorm(f.areaVector)*squaredNorm(d));
        const std::array<double,5> terms{base,mismatch,covariance,q[id],projected};
        for(std::size_t k=0;k<terms.size();++k){energies[k]-=dp*terms[k];fluxSquared[k]+=terms[k]*terms[k];}
        const double error=q[id]-base-mismatch-covariance;
        maximumError=std::max(maximumError,std::abs(error));maximum=std::max(maximum,std::abs(q[id]));
        const double cosine=std::clamp(dot(f.areaVector,d)/std::sqrt(squaredNorm(f.areaVector)*squaredNorm(d)),-1.,1.);
        faces<<id<<','<<std::acos(cosine)*180/std::acos(-1.)<<','<<base<<','<<mismatch<<','<<covariance<<','<<q[id]<<','<<error<<'\n';
    }
    const std::array<const char*,5> names{"baseLS","gradientMismatch","rAUCovariance","nativeTotal","projectedBaseLS"};
    std::cout<<std::setprecision(17)<<"{\"cells\":"<<n<<",\"terms\":{";
    for(std::size_t k=0;k<5;++k){if(k)std::cout<<',';std::cout<<'"'<<names[k]<<"\":{\"pressureEnergy\":"<<double(energies[k])<<",\"faceFluxL2\":"<<std::sqrt(double(fluxSquared[k]))<<'}';}
    std::cout<<"},\"maximumDecompositionError\":"<<maximumError<<",\"maximumNativePressureFlux\":"<<maximum<<"}\n";
    return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
