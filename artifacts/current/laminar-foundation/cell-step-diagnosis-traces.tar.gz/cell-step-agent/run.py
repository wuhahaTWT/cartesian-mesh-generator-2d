#!/usr/bin/env python3
"""Command timing, file hashes, and packaging of native CSV evidence only.

No PDE, matrix, gradient, flux, power iteration, or projection is implemented here.
"""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import time

out = Path(__file__).resolve().parent
root = out.parent.parent
mesh = root/'outputs/laminar-inputs/annulus-l7.solver.cm2d'
boundary = root/'outputs/laminar-inputs/annulus-l7.boundaries'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_hashes():
    return {str(p.relative_to(root)): sha(p)
            for tree in ('src', 'include') for p in sorted((root/tree).rglob('*')) if p.is_file()}

def rows(path):
    with path.open() as f:
        return list(csv.DictReader(f))

before = source_hashes()
libraries = [root/'build/libcartmesh2d_fv.a', root/'build/libcartmesh2d.a']
lib_before = {str(p):sha(p) for p in libraries}
records=[]
for name in ('trace', 'plain'):
    binary=out/('cell_step' if name=='trace' else 'cell_step_plain')
    command=[str(binary),str(mesh),str(boundary),str(out/name),'3710','180']
    started=time.time()
    monotonic=time.monotonic()
    result=subprocess.run(command,cwd=root,capture_output=True,text=True)
    elapsed=time.monotonic()-monotonic
    (out/(name+'-stdout.log')).write_text(result.stdout)
    (out/(name+'-stderr.log')).write_text(result.stderr)
    records.append({'name':name,'command':command,'cwd':str(root),'startedUnixSeconds':started,
                    'elapsedWallSeconds':elapsed,'returnCode':result.returncode,
                    'binarySha256':sha(binary),'stdout':result.stdout,'stderr':result.stderr})
    if result.returncode:
        raise SystemExit(result.returncode)
after=source_hashes()
lib_after={str(p):sha(p) for p in libraries}
comparisons={name:(out/'trace'/name).read_bytes()==(out/'plain'/name).read_bytes()
             for name in ('input-modal-cells.csv','input-modal-faces.csv','output-modal-cells.csv',
                          'output-modal-faces.csv','output-base-cells.csv','output-base-faces.csv',
                          'output-delta-cells.csv','output-delta-faces.csv','power.csv')}
target_ids={'3710','3711'}
face_ids={r['face0'] for r in rows(out/'trace/momentum-face-terms.csv') if r['cell0'] in target_ids}
metadata={
    'scope':'One whole-mesh production Stokes SIMPLE step observed at target cells. Read-only GNU ld --wrap. No solver/default change; no full matrix benchmark; no causal source attribution.',
    'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'sourceBranch':subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip(),
    'sourceFilesSha256Before':before,'sourceFilesSha256After':after,'sourceFilesUnchanged':before==after,
    'productionLibrariesSha256Before':lib_before,'productionLibrariesSha256After':lib_after,
    'productionLibrariesUnchanged':lib_before==lib_after,
    'inputs':[{'path':str(p),'sha256':sha(p)} for p in (mesh,boundary)],
    'build':json.loads((out/'build-commands.json').read_text()),'runs':records,
    'controls':{'nu':'.1 m2/s','speed':'.5 m/s','momentumInertia':'0 (Stokes)',
                'alphaU':'.6 (production default)','alphaP':'.25 (production default)',
                'pressureCorrectionPasses':4,'pressurePreconditioner':'production IC0 on Linux',
                'viscousStress':'Symmetric','convection':'FaceLimitedLinearUpwind',
                'maxIterationsPerProductionSolve':1,'powerIterationSteps':180},
    'indexing':'All cell0/face0/owner0/neighbour0 are zero-based; cell1 is one-based. User cell 3711 is target cell0=3710; adjacent cell0=3711 is also reported.',
    'units':'Integrated per-depth momentum RHS/actions: m3/s2. Momentum coefficients: m2/s. Face flux/RC: m2/s. Pressure: m2/s2. These are never added across tables.',
    'capture':'Recording disabled for modal reconstruction; records only the next F(x) and F(0), each with pre U/V, one actual RC predictor, post U/V. Physical boundary values are identical; delta cancels affine wall Dirichlet RHS.',
    'projection':'Velocity and pressure use cell area weights separately; flux uses face length weights. Each projection divides by the corresponding input field squared norm; dimensions never mix. These describe stages, not source causality.',
    'unwrappedByteComparison':comparisons,
    'traceEnabledVsDisabled':rows(out/'trace/trace-invariance.csv'),
    'summary':rows(out/'trace/summary.csv'),
    'alignmentAllCells':rows(out/'trace/alignment.csv'),
    'stageProjections':rows(out/'trace/stage-projection.csv'),
    'targetStageResponses':[r for r in rows(out/'trace/stage-target-response.csv') if r['cell0'] in target_ids],
    'targetCompleteViscousActions':[r for r in rows(out/'trace/momentum-old-field-action.csv') if r['run']=='delta' and r['cell0'] in target_ids],
    'targetMomentumRows':[r for r in rows(out/'trace/momentum-rows.csv') if r['run']=='delta' and r['cell0'] in target_ids],
    'targetFaceMomentumTerms':[r for r in rows(out/'trace/momentum-face-terms.csv') if r['run']=='delta' and r['cell0'] in target_ids],
    'targetFaceRcTerms':[r for r in rows(out/'trace/rc-face-terms.csv') if r['run']=='delta' and r['face0'] in face_ids],
    'consumer':'Root analysis uses the actual production matrix and predictor/correction state for native source attribution. CSV fields and hashes are reproducible; binaries and plain outputs are rebuildable temporary products.'
}
(out/'result.json').write_text(json.dumps(metadata,indent=2)+'\n')
assert before==after and lib_before==lib_after and all(comparisons.values())
print(json.dumps({'seconds':{r['name']:r['elapsedWallSeconds'] for r in records},
                  'sourceUnchanged':before==after,'librariesUnchanged':lib_before==lib_after,
                  'unwrappedByteComparisons':comparisons,'result':str(out/'result.json')},indent=2))
