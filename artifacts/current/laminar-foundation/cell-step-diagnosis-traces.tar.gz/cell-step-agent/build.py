#!/usr/bin/env python3
"""Compile only standalone probes against existing production archives."""
from pathlib import Path
import json
import subprocess

out = Path(__file__).resolve().parent
root = out.parent.parent
symbols = subprocess.check_output(['nm', '-g', '--defined-only', str(root/'build/libcartmesh2d_fv.a')], text=True)
selected = {}
for name in ('momentum', 'rhieChowFlux'):
    matches = [line.split()[-1] for line in symbols.splitlines() if ' T ' in line and name in line]
    assert len(matches) == 1, (name, matches)
    selected[name] = matches[0]
(out/'symbols.hpp').write_text(''.join(f'#define {name.upper()}_SYMBOL "{symbol}"\n' for name, symbol in selected.items()))
commands=[]
for wrapped in (False, True):
    cmd=['/usr/bin/c++', '-O3', '-DNDEBUG', '-std=gnu++20', '-I'+str(root/'include'), '-I'+str(root/'src/fv'), str(out/'cell_step.cpp')]
    if wrapped:
        cmd += ['-DDIAG_WRAP'] + ['-Wl,--wrap='+symbol for symbol in selected.values()]
    cmd += [str(root/'build/libcartmesh2d_fv.a'), str(root/'build/libcartmesh2d.a'), '-o', str(out/('cell_step' if wrapped else 'cell_step_plain'))]
    commands.append(cmd)
    subprocess.run(cmd, check=True)
(out/'build-commands.json').write_text(json.dumps({'symbols':selected, 'commands':commands}, indent=2)+'\n')
