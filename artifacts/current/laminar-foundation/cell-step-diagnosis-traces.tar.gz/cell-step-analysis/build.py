#!/usr/bin/env python3
"""Build native source attribution with the same GNU wrappers as the trace."""
from pathlib import Path
import json
import subprocess

out = Path(__file__).resolve().parent
root = out.parent.parent
prior = json.loads((root / 'outputs/cell-step-agent/build-commands.json').read_text())
cmd = prior['commands'][1].copy()
idx = next(i for i, value in enumerate(cmd) if value.endswith('/cell_step.cpp'))
cmd[idx] = str(out / 'source_response.cpp')
cmd[-1] = str(out / 'source_response')
(out / 'build-command.json').write_text(json.dumps(cmd, indent=2) + '\n')
subprocess.run(cmd, check=True)
