#!/usr/bin/env python3
"""Run native source attribution; package its measured CSV results and hashes."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import time

out = Path(__file__).resolve().parent
root = out.parent.parent
trace = root / 'outputs/cell-step-agent'
mesh = root / 'outputs/laminar-inputs/annulus-l7.solver.cm2d'
boundary = root / 'outputs/laminar-inputs/annulus-l7.boundaries'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rows(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))

libraries = [root / 'build/libcartmesh2d_fv.a', root / 'build/libcartmesh2d.a']
before = {str(path): sha(path) for path in libraries}
command = [str(out / 'source_response'), str(mesh), str(boundary),
           str(trace / 'trace'), str(out / 'response')]
started = time.monotonic()
run = subprocess.run(command, cwd=root, capture_output=True, text=True)
elapsed = time.monotonic() - started
(out / 'run.log').write_text(run.stdout + run.stderr)
if run.returncode:
    raise SystemExit(run.returncode)
after = {str(path): sha(path) for path in libraries}
assert before == after
replay = {}
for native, original in [('replayed-modal', 'output-modal'), ('replayed-base', 'output-base')]:
    for kind in ['cells', 'faces']:
        name = native + '-' + kind + '.csv'
        replay[name] = ((out / 'response' / name).read_bytes() ==
                        (trace / 'trace' / (original + '-' + kind + '.csv')).read_bytes())
assert all(replay.values())
result = {
    'scope': 'Native source attribution of the same retained Stokes mode. All terms retained. Only fixed-viscosity, closed fixed-velocity walls, identical modal/base matrices and zero volume sources are supported.',
    'sourceHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'command': command,
    'cwd': str(root),
    'elapsedWallSecondsIncludingIO': elapsed,
    'returnCode': run.returncode,
    'stdout': run.stdout,
    'buildCommand': json.loads((out / 'build-command.json').read_text()),
    'sourceSha256': sha(out / 'source_response.cpp'),
    'binarySha256': sha(out / 'source_response'),
    'productionLibrariesSha256Before': before,
    'productionLibrariesSha256After': after,
    'productionLibrariesUnchanged': before == after,
    'replayedProductionFieldsByteEqual': replay,
    'projection': 'Separate cell-area velocity/pressure and face-length flux weighted inner products, divided by corresponding modal input squared norms; identical to the native step trace.',
    'linearControls': 'Production Jacobi momentum solve: relative 1e-11 and row stop .01*tolerance*speed*alphaU; IC(0) pressure relative 1e-11, four native pressure passes and their final lagged correction. Separate Krylov solves have finite stopping error; closure is numerical, not bitwise.',
    'method': 'Actual captured compact diagonal/offdiagonal retained in every momentum solve. Native sources separately propagated through native velocity gradient, Rhie-Chow interpolation and solvePressureCorrection. Pressure direct RC terms, retained face-flux relaxation and old pressure carry added separately. No source deletion or changed discretization.',
    'sourceProjections': rows(out / 'response/source-projection.csv'),
    'sourceTargets': rows(out / 'response/source-target.csv'),
    'pressurePassResponses': rows(out / 'response/pressure-pass-response.csv'),
    'closure': rows(out / 'response/response-closure.csv'),
    'limitations': 'This decomposes one linear map response at its retained observed mode. A large source contribution is not proof of a unique instability cause. It is not a spectrum bound, a physical field, an accuracy repair, or a term-deletion counterfactual.',
    'consumer': 'Focused native coupling/stress investigation. Complete modal input and output plus native matrix/gradient traces permit replay; rebuilt binaries and repeated full CSV views remain temporary.'
}
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'elapsedWallSecondsIncludingIO': elapsed, 'replayedFieldsByteEqual': replay,
                  'librariesUnchanged': before == after}, indent=2))
