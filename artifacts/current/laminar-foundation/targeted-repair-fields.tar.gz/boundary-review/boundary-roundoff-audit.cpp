#include "cartmesh2d/fv/detail/FlowFaceOperators2D.hpp"
#include "cartmesh2d/fv/FlowBoundaryIO2D.hpp"
#include "cartmesh2d/io/MeshIO2D.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
using namespace cartmesh2d;
using namespace cartmesh2d::fv;
struct Metrics {double la,lb,coordinate,angle,plane,touch,required;};
static Metrics metrics(const Face& a,const Face& b) {
    const double la=std::hypot(a.areaVector.x,a.areaVector.y),lb=std::hypot(b.areaVector.x,b.areaVector.y);
    const auto na=a.areaVector*(1/la),nb=b.areaVector*(1/lb),delta=b.centre-a.centre;
    const double coordinate=std::max({la,lb,std::abs(a.centre.x),std::abs(a.centre.y),std::abs(b.centre.x),std::abs(b.centre.y)});
    double distance=std::numeric_limits<double>::infinity();
    for(const double sa:{-.5,.5})for(const double sb:{-.5,.5}) {
        const double dx=(a.centre.x+sa*a.areaVector.y)-(b.centre.x+sb*b.areaVector.y);
        const double dy=(a.centre.y-sa*a.areaVector.x)-(b.centre.y-sb*b.areaVector.x);
        distance=std::min(distance,std::hypot(dx,dy));
    }
    const double unit=std::numeric_limits<double>::epsilon()*coordinate;
    const double angle=std::abs(na.x*nb.y-na.y*nb.x)*std::min(la,lb)/unit;
    const double plane=std::abs(delta.x*na.x+delta.y*na.y)/unit;
    const double touch=distance/unit;
    return {la,lb,coordinate,angle,plane,touch,std::max({angle,plane,touch})};
}
int main(int argc,char** argv) {try {
    if(argc!=4)throw std::runtime_error("boundary-roundoff-audit MESH BC OUTPUT");
    const auto input=readCm2dTopology(argv[1]);if(!input.valid())throw std::runtime_error(input.error);
    const auto mesh=makeFvMesh2D(input.topology);FlowControls2D c;c.scenario="custom";
    std::ifstream stream(argv[2]);c.boundaryConditions=readFlowBoundaryConditions2D(stream,mesh,c);
    std::vector<std::size_t> groups(mesh.faces.size());std::vector<bool> fixed(mesh.faces.size());
    std::vector<std::string> names(mesh.faces.size());std::map<std::string,std::size_t> nameGroups;
    for(const auto& bc:c.boundaryConditions) {
        fixed[bc.face]=bc.kind!=FlowBoundaryKind2D::PressureOutlet&&bc.kind!=FlowBoundaryKind2D::PressureOpening&&bc.kind!=FlowBoundaryKind2D::VelocityOutlet;
        groups[bc.face]=nameGroups.emplace(bc.name,nameGroups.size()).first->second;names[bc.face]=bc.name;
    }
    const auto original=detail::buildFlowGradientStencil2D(mesh,fixed);
    const auto product=detail::buildFlowGradientStencil2D(mesh,fixed,false,groups);
    std::ofstream out(argv[3]);out<<std::setprecision(17)<<"{\"inputMesh\":\""<<argv[1]<<"\",\"constructionMultiplier\":128,\"groupPairs\":[";
    bool first=true;std::size_t count=0;std::set<std::size_t> changed;
    double needed=0,minLength=std::numeric_limits<double>::infinity();
    double minOldDet=std::numeric_limits<double>::infinity(),minNewDet=minOldDet;
    for(std::size_t cell=0;cell<mesh.cells.size();++cell) {
        const auto& ids=mesh.cells[cell].faces;
        for(std::size_t i=0;i<ids.size();++i)for(std::size_t j=i+1;j<ids.size();++j) {
            const auto ia=ids[i],ib=ids[j];const auto& a=mesh.faces[ia];const auto& b=mesh.faces[ib];
            if(a.neighbour||b.neighbour||fixed[ia]!=fixed[ib]||groups[ia]!=groups[ib]||a.patch!=b.patch)continue;
            if(!detail::sameGradientBoundaryPlane2D(a,b)||!detail::gradientBoundarySegmentsTouch2D(a,b))continue;
            const auto m=metrics(a,b);needed=std::max(needed,m.required);minLength=std::min({minLength,m.la,m.lb});changed.insert(cell);++count;
            minOldDet=std::min(minOldDet,original.rows[cell].det);minNewDet=std::min(minNewDet,product.rows[cell].det);
            if(!first)out<<',';first=false;
            out<<"{\"cell\":"<<cell<<",\"a\":"<<ia<<",\"b\":"<<ib<<",\"name\":\""<<names[ia]
               <<"\",\"lengths\":["<<m.la<<','<<m.lb<<"],\"coordinateScale\":"<<m.coordinate
               <<",\"requiredAngleMultiplier\":"<<m.angle<<",\"requiredPlaneMultiplier\":"<<m.plane
               <<",\"requiredTouchMultiplier\":"<<m.touch<<",\"requiredMultiplier\":"<<m.required
               <<",\"originalDet\":"<<original.rows[cell].det<<",\"productDet\":"<<product.rows[cell].det<<'}';
        }
    }
    out<<"],\"groupPairCount\":"<<count<<",\"changedCellCount\":"<<changed.size()<<",\"minimumMultiplierCoveringAllActualPairs\":"<<needed
       <<",\"minimumGroupedFaceLength\":"<<minLength<<",\"minimumChangedOriginalDet\":"<<minOldDet
       <<",\"minimumChangedProductDet\":"<<minNewDet<<",\"scope\":\"Existing native input and inline reconstruction only; no PDE solve or topology mutation.\"}\n";
    std::cout<<"pairs="<<count<<" cells="<<changed.size()<<" min_multiplier="<<std::setprecision(17)<<needed<<"\n";
    return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
