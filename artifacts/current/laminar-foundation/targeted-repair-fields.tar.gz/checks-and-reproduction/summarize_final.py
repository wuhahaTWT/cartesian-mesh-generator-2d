#!/usr/bin/env python3
"""Summarize actual native outputs; CSV comparisons only, no PDE reconstruction."""
import csv
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools/benchmarks'))
import laminar

OUT = ROOT / 'outputs/pressure-response'
FINAL = OUT / 'final'
ART = ROOT / 'artifacts/current/laminar-foundation'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def physical(label, summary):
    prefix = FINAL / label
    metrics = laminar.evaluate('annulus' if label.startswith('annulus') else 'dfg20', prefix, summary)
    if label.startswith('annulus'):
        rows = laminar.meshio.read_cells(str(prefix) + '.cells.csv')
        area = math.fsum(r['area'] for r in rows)
        stokes = 'stokes' in label
        errors = []
        for r in rows:
            radius = math.hypot(r['x'], r['y'])
            exact = 0. if stokes else radius**2 / 18 - 2 / 9 * math.log(radius) - 1 / (18 * radius**2)
            errors.append(r['p'] - exact)
        mean = math.fsum(r['area'] * e for r, e in zip(rows, errors)) / area
        metrics['pressureMeanFreeL2'] = math.sqrt(math.fsum(r['area'] * (e-mean)**2 for r, e in zip(rows, errors)) / area) / .25
        if stokes:
            metrics['pressureL2'] = math.sqrt(math.fsum(r['area'] * r['p']**2 for r in rows) / area) / .25
        metrics['pressureReference'] = 'circular Stokes constant pressure' if stokes else 'circular NS analytic pressure'
        metrics['qualification'] = 'Same circular-reference diagnostic before/after; original polygon wall trace differs from the circular problem.'
    return metrics


records = read(FINAL / 'runs.json') + read(FINAL / 'accuracy-runs.json')
assert len(records) == 11
for record in records:
    label = record['label']
    summary = record['summary']
    expected = label != 'annulus-l7-simple-prefix'
    assert summary['converged'] == expected
    assert record['returnCode'] == (0 if expected else 2)
    if expected:
        assert summary['strictLinearFinal']
        assert summary['momentumResidual'] < 1e-8 and summary['continuity'] < 1e-8
        assert summary['fluxConsistency'] < 1e-8
        record['physicalMetrics'] = physical(label, summary)
    record['filesSha256'] = {f.name: sha(f) for f in FINAL.glob(label + '.*')
                            if f.suffix == '.csv' or f.name.endswith(('.log', '.performance.json'))}
    record['reproductionCommand'] = [str(s).replace(str(ROOT) + '/', '') for s in record['command']]
    record['reproductionCommand'][0] = 'build/cartmesh2d_flow_cli'
    record['originalCommand'] = record.pop('command')
    record['nativeSummaryFile'] = 'final/' + label + '.json'
    record['boundaryFaceConditions'] = len(summary.pop('boundaryConditions', []))
    record['sourceInputsSha256'] = {str(Path(record['originalCommand'][record['originalCommand'].index(flag) + 1]).relative_to(ROOT)):
                                   sha(Path(record['originalCommand'][record['originalCommand'].index(flag) + 1]))
                                   for flag in ('--mesh', '--boundary')}

metrics = {r['label']: r.get('physicalMetrics') for r in records}
(FINAL / 'physical-metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
by_label = {r['label']: r for r in records}
segment = read(ROOT / 'outputs/local-mechanism/segment-summary.json')
comparison = {}
for level in (5, 6, 7):
    before = segment['annulus'][str(level)]['before']
    after = metrics[f'annulus-l{level}-coupled-face-limited']
    comparison[str(level)] = {
        'convection': 'face-limited-linear',
        'before': {k: before[k] for k in ('velocityL2', 'pressureMeanFreeL2')},
        'after': {k: after[k] for k in ('velocityL2', 'pressureMeanFreeL2')},
        'relativeChange': {k: after[k] / before[k] - 1 for k in ('velocityL2', 'pressureMeanFreeL2')},
    }


def max_field_difference(base, other):
    out = {}
    for suffix, fields in (('.cells.csv', ('u', 'v', 'p')), ('.faces.csv', ('flux',))):
        with (FINAL / (base + suffix)).open() as f:
            a = list(csv.DictReader(f))
        with (FINAL / (other + suffix)).open() as f:
            b = list(csv.DictReader(f))
        assert len(a) == len(b)
        for key in fields:
            out[key] = max(abs(float(x[key]) - float(y[key])) for x, y in zip(a, b))
    return out


app = read(OUT / 'app.png.json')
pressure_only = {}
for name in ('annulus-l5', 'annulus-l7', 'dfg20-l7'):
    summary = read(OUT / (name + '.json'))
    pressure_only[name] = {k: summary[k] for k in ('converged', 'iterations', 'momentumResidual', 'continuity', 'velocityChange', 'pressureChange', 'fluxConsistency', 'strictLinearFinal', 'coupling', 'convection')}
evidence = {
    'format': 'cartmesh2d-targeted-incompressible-repair-v1',
    'date': '2026-10-08',
    'scope': 'Full relaxed momentum response and subdivision-invariant straight-boundary velocity reconstruction. Native 2D code; no removed cells or relaxed acceptance gates.',
    'provenance': read(FINAL / 'provenance.json'),
    'implementation': {
        'simpleConsistent': 'Opt-in block solve of full frozen momentum/pressure response, with hU=D/alphaU-aU and hV=D/alphaU-aV, matching old-state sources and (1-alphaU)*(oldPhi-T(oldU)) face defect. Compute U/phi with pHat before mixing stored p by alphaP. Shared original physical residual and strict final certification.',
        'boundarySubdivision': segment['decision'],
        'defaultCoupling': 'simple, unchanged; still unstable on retained fine annulus',
        'supportedScope': 'Steady, constant-viscosity, fixed-role, strict native flow. CLI/API only; no desktop selector added.',
    },
    'runs': records,
    'sameSchemeAnnulusComparison': comparison,
    'dfgBefore': segment['dfg']['results']['original'],
    'dfgAfter': metrics['dfg20-l7-coupled'],
    'completeFieldMaxAbsDifferenceConsistentVsCoupled': {
        name: max_field_difference(name + '-coupled', name + '-consistent')
        for name in ('annulus-l7', 'dfg20-l7')
    },
    'pressureResponseWithoutBoundaryChange': {
        'results': pressure_only,
        'sourceProvenance': read(OUT / 'pressure-only-source.json'),
        'qualification': 'Earlier successful control; exact source patch retained but its running executable was not hashed before replacement. Final delivery uses the separately hashed frozen executable and original inputs above. No binary identity or performance claim for this supplemental run.',
    },
    'wallOnlyDiagnostic': segment['simple'],
    'boundaryOperatorStudy': segment,
    'roundoffReview': read(ROOT / 'outputs/numerical-design/boundary-roundoff-review.json'),
    'regressions': {
        'native': {'total': 105, 'passedAcrossRuns': 105, 'firstParallelPass': 103,
                   'firstParallelTimeouts': ['cartmesh2d_euler_core', 'cartmesh2d_flow_boundary'],
                   'serialRetryUnchangedControls': 'both passed', 'build': 'GCC 14.2 Release, Cantera OFF'},
        'newCases': ['five velocity/pressure relaxation pairs', 'unequal slip component diagonals', 'same full fixed point including face flux and wall loads', 'manufactured source', 'strict final and flux consistency', 'cancel/minimum-iteration/unsupported-control/failed-candidate accepted-state preservation', 'CLI case-file metadata/reproducibility', 'affine and subdivision-invariant gradient; cache live values and partition changes', 'boundary scales/translations, resolved corners and disconnected fragments'],
        'frontend': {'passed': 191, 'failed': 0, 'environment': 'network permission enabled for child-process/local IPC checks', 'initialSandboxAttempt': 'hung; terminated and retained, not counted as passing'},
        'desktopRuntime': 'rebuilt successfully, flow executable byte-identical to benchmark snapshot',
        'actualLinuxApp': {'summary': app['flow']['summary'], 'fieldCells': app['flow']['fieldCells'], 'interactionChecks': app.get('interactionChecks'), 'screenshotLocal': 'outputs/pressure-response/app.png', 'metadataLocal': 'outputs/pressure-response/app.png.json'},
        'platformCI': 'Not run in this delivery; gh auth status reports configured GH_TOKEN invalid. No macOS/Windows qualification claimed.',
    },
    'cleanup': {'branches': read(OUT / 'branch-cleanup-result.json'), 'files': read(OUT / 'file-cleanup-result.json')},
    'remainingLimits': [
        'Default SIMPLE remains unstable; wall reconstruction alone does not fix iteration amplification.',
        'DFG lift error worsens from 30.27% to 48.32%; pressure-drop error also slightly worsens. No general physical-accuracy certification.',
        'Annulus inner torque error does not improve in every refinement level.',
        '128*epsilon construction-scale line classification can merge real micro-corners within its declared roundoff budget; real geometry is never modified.',
        'Preserving relaxation is substantially more iterative than unrelaxed coupled on these inputs; timing is not isolated.',
        'No general arbitrary-mesh or 100k/300k/500k-cell convergence claim; higher-density runs remain paused.',
    ],
    'consumers': {
        'retainedInputs': 'Original native meshes and boundary files in existing failure-inputs.tar.gz; use original byte hashes in runs. No new input or geometry was substituted.',
        'fieldArchive': 'targeted-repair-fields.tar.gz: real accepted u/v/p/face flux, convergence histories, source patches, failed controls and check logs. Frozen binaries, build/cache and duplicated large exports remain local/rebuildable.',
        'reproduction': 'Use the committed source and docs/DEVELOPMENT_CN.md; archive scripts only invoke the native solver or compare exported CSVs, never reimplement PDE operators.',
        'branchRecovery': 'git switch -c <recovery-name> archive/2026-10-08/<original-branch>; archival tag is not integration or numerical qualification.',
    },
}
(ART / 'targeted-repair.json').write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'runs': len(records), 'annulusComparison': comparison['7'],
                  'fixedPointDifference': evidence['completeFieldMaxAbsDifferenceConsistentVsCoupled'],
                  'consistentIterations': {k: by_label[k]['summary']['iterations'] for k in ('annulus-l7-consistent','dfg20-l7-consistent')}}, indent=2))
