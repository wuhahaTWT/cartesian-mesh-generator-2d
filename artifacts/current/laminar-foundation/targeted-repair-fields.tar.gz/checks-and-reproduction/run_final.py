#!/usr/bin/env python3
"""Run the native solver only; preserve real outputs and failure status."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/pressure-response/final'
INPUT = ROOT / 'outputs/laminar-refactor/inputs'
CLI = OUT / 'flow-cli'
SHA = hashlib.sha256(CLI.read_bytes()).hexdigest()
cases = [
    ('annulus-l5-coupled', 'annulus-l5', 'coupled', 1, 200),
    ('annulus-l6-coupled', 'annulus-l6', 'coupled', 1, 200),
    ('annulus-l7-coupled', 'annulus-l7', 'coupled', 1, 200),
    ('annulus-l7-stokes-coupled', 'annulus-l7', 'coupled', 0, 200),
    ('dfg20-l7-coupled', 'dfg20-l7', 'coupled', 1, 300),
    ('annulus-l7-simple-prefix', 'annulus-l7', 'simple', 1, 40),
    ('annulus-l7-consistent', 'annulus-l7', 'simple-consistent', 1, 3500),
    ('dfg20-l7-consistent', 'dfg20-l7', 'simple-consistent', 1, 1800),
]
records = []
for label, mesh, coupling, inertia, budget in cases:
    dfg = mesh.startswith('dfg')
    prefix = OUT / label
    command = [str(CLI), '--mesh', str(INPUT / (mesh + '.solver.cm2d')),
               '--boundary', str(INPUT / (mesh + '.boundaries')), '--case', 'custom',
               '--coupling', coupling, '--nu', '.001' if dfg else '.1',
               '--speed', '.3' if dfg else '.5', '--viscous-stress', 'symmetric',
               '--convection', 'limited-linear' if dfg else 'upwind',
               '--momentum-inertia', str(inertia), '--max-iterations', str(budget),
               '--tolerance', '1e-8', '--profile', '--output', str(prefix)]
    if coupling != 'simple':
        command += ['--linear-policy', 'adaptive']
    assert hashlib.sha256(CLI.read_bytes()).hexdigest() == SHA
    record = dict(label=label, command=command, binarySha256=SHA)
    start = time.monotonic()
    with prefix.with_suffix('.log').open('w') as log:
        try:
            process = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=2100)
            record['returnCode'] = process.returncode
        except subprocess.TimeoutExpired:
            record['returnCode'] = None
            record['failure'] = 'process timeout; not convergence'
    record['wallSeconds'] = time.monotonic() - start
    record['sourceInputsSha256'] = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                   for p in (INPUT / (mesh + '.solver.cm2d'), INPUT / (mesh + '.boundaries'))}
    for suffix, key in (('.json', 'summary'), ('.performance.json', 'performance')):
        path = prefix.with_suffix(suffix)
        if path.exists():
            record[key] = json.loads(path.read_text())
    records.append(record)
    (OUT / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, 'exit', record['returnCode'], 'iterations', record.get('summary', {}).get('iterations'),
          'converged', record.get('summary', {}).get('converged'), flush=True)
