#!/usr/bin/env bash
set -euo pipefail
# Run from the repository root. These archives are local frozen research inputs.
# Other native library versions require a fresh ABI-compatible Equation build.
task_dir=outputs/local-mechanism
compiler=/usr/bin/c++
"$compiler" -O3 -DNDEBUG -std=c++20 -I"$task_dir/segment-baseline-headers" -Iinclude -Isrc/fv -I"$task_dir" -c "$task_dir/StudyEquation.cpp" -o "$task_dir/StudyEquation.o"
for driver in segment-study segment-study-dfg-controls segment-study-simple; do
  "$compiler" -O3 -DNDEBUG -std=c++20 -I"$task_dir/segment-baseline-headers" -Iinclude -Isrc/fv -I"$task_dir" "$task_dir/$driver.cpp" "$task_dir/StudyEquation.o" "$task_dir/segment-baseline-fv.a" "$task_dir/segment-baseline-mesh.a" -o "$task_dir/$driver-rebuilt"
done
"$compiler" -O3 -DNDEBUG -std=c++20 -I"$task_dir/segment-baseline-headers" -Iinclude -Isrc/fv -I"$task_dir" "$task_dir/segment-mode.cpp" "$task_dir/segment-baseline-fv.a" "$task_dir/segment-baseline-mesh.a" -o "$task_dir/segment-mode-rebuilt"
# Same preserved input and original physical wall conditions.
"$task_dir/segment-study-rebuilt" outputs/laminar-refactor/inputs/annulus-l7.solver.cm2d outputs/laminar-refactor/inputs/annulus-l7.boundaries annulus 1 "$task_dir/rebuilt-annulus"
"$task_dir/segment-study-dfg-controls-rebuilt" outputs/laminar-refactor/inputs/dfg20-l7.solver.cm2d outputs/laminar-refactor/inputs/dfg20-l7.boundaries dfg 1 "$task_dir/rebuilt-dfg"
"$task_dir/segment-mode-rebuilt" outputs/laminar-refactor/inputs/annulus-l7.solver.cm2d outputs/laminar-refactor/inputs/annulus-l7.boundaries 120 0 3710 1 power > "$task_dir/rebuilt-mode.csv"
