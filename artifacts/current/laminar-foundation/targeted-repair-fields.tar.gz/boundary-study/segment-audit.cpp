#include "SegmentGradientStudy.hpp"
#include "cartmesh2d/fv/FlowBoundaryIO2D.hpp"
#include "cartmesh2d/io/MeshIO2D.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace cartmesh2d;
using namespace cartmesh2d::fv;
int main(int argc,char** argv){try{
    if(argc!=3)throw std::runtime_error("segment-audit MESH BC");const auto in=readCm2dTopology(argv[1]);if(!in.valid())throw std::runtime_error(in.error);const auto mesh=makeFvMesh2D(in.topology);
    FlowControls2D c;c.scenario="custom";std::ifstream file(argv[2]);c.boundaryConditions=readFlowBoundaryConditions2D(file,mesh,c);
    std::vector<bool> fixed(mesh.faces.size());std::vector<double> bc(mesh.faces.size()),value(mesh.cells.size());
    std::vector<std::size_t> groups(mesh.faces.size());std::map<std::string,std::size_t> namedGroups;
    for(const auto& b:c.boundaryConditions){fixed[b.face]=b.kind!=FlowBoundaryKind2D::PressureOutlet&&b.kind!=FlowBoundaryKind2D::PressureOpening&&b.kind!=FlowBoundaryKind2D::VelocityOutlet;bc[b.face]=b.velocity.x;groups[b.face]=namedGroups.emplace(b.name,namedGroups.size()).first->second;}
    for(std::size_t i=0;i<value.size();++i){const auto x=mesh.cells[i].centre;value[i]=std::sin(x.x)+.4*std::cos(2*x.y);}
    auto split=mesh;split.faces.clear();for(auto& cell:split.cells)cell.faces.clear();std::vector<bool> splitFixed;std::vector<double> splitBC;std::vector<std::size_t> splitGroups;
    for(std::size_t id=0;id<mesh.faces.size();++id){const auto& f=mesh.faces[id];const int count=f.neighbour?1:4;
        for(int k=0;k<count;++k){auto q=f;const double shift=(k+.5)/count-.5;q.centre={f.centre.x-shift*f.areaVector.y,f.centre.y+shift*f.areaVector.x};q.areaVector=q.areaVector*(1./count);q.transmissibility/=count;
            const auto d=(f.neighbour?mesh.cells[*f.neighbour].centre:q.centre)-mesh.cells[f.owner].centre;q.correction={q.areaVector.x-d.x*q.transmissibility,q.areaVector.y-d.y*q.transmissibility};
            const auto sid=split.faces.size();split.faces.push_back(q);split.cells[q.owner].faces.push_back(sid);if(q.neighbour)split.cells[*q.neighbour].faces.push_back(sid);splitFixed.push_back(fixed[id]);splitBC.push_back(bc[id]);splitGroups.push_back(groups[id]);}}
    validateFvMesh2D(split);
    const auto orig=detail::flowGradient(mesh,value,bc,fixed),sub=detail::flowGradient(split,value,splitBC,splitFixed);
    const segment_study::Stencil a(mesh,fixed),b(split,splitFixed);const auto ag=a.apply(value,bc),bg=b.apply(value,splitBC);
    const auto product=detail::flowGradient(mesh,value,bc,fixed,false,nullptr,groups);
    const auto productSplit=detail::flowGradient(split,value,splitBC,splitFixed,false,nullptr,splitGroups);
    const auto cache=detail::buildFlowGradientStencil2D(mesh,fixed,false,groups);const auto cached=cache.apply(value,bc);
    double productVsPrototype=0,productSplitMax=0,cacheDifference=0;std::size_t productChangedCells=0,productGroupedFaces=0;
    for(std::size_t i=0;i<value.size();++i){productVsPrototype=std::max(productVsPrototype,std::hypot(product[i].x-ag[i].x,product[i].y-ag[i].y));productSplitMax=std::max(productSplitMax,std::hypot(product[i].x-productSplit[i].x,product[i].y-productSplit[i].y));cacheDifference=std::max(cacheDifference,std::hypot(product[i].x-cached[i].x,product[i].y-cached[i].y));const auto redundant=std::lround(mesh.cells[i].faces.size()-cache.rows[i].xx-cache.rows[i].yy);if(redundant>0){++productChangedCells;productGroupedFaces+=redundant;std::cerr<<std::setprecision(17)<<"changed_cell,"<<i<<','<<mesh.cells[i].centre.x<<','<<mesh.cells[i].centre.y<<','<<redundant<<'\n';for(const auto fid:mesh.cells[i].faces)if(!mesh.faces[fid].neighbour){const auto entry=std::find_if(c.boundaryConditions.begin(),c.boundaryConditions.end(),[&](const auto& x){return x.face==fid;});std::cerr<<"changed_face,"<<i<<','<<fid<<','<<entry->name<<','<<flowBoundaryKindName2D(entry->kind)<<','<<static_cast<int>(mesh.faces[fid].patch)<<'\n';}}}
    double originalMax=0,aggregateMax=0,changeMax=0;long double originalL2=0,aggregateL2=0,area=0;
    for(std::size_t i=0;i<value.size();++i){const double e=std::hypot(orig[i].x-sub[i].x,orig[i].y-sub[i].y),g=std::hypot(ag[i].x-bg[i].x,ag[i].y-bg[i].y);originalMax=std::max(originalMax,e);aggregateMax=std::max(aggregateMax,g);changeMax=std::max(changeMax,std::hypot(orig[i].x-ag[i].x,orig[i].y-ag[i].y));area+=mesh.cells[i].area;originalL2+=mesh.cells[i].area*e*e;aggregateL2+=mesh.cells[i].area*g*g;}
    auto linear=[](Point2D p){return 1.2+.3*p.x-.7*p.y;};for(std::size_t i=0;i<value.size();++i)value[i]=linear(mesh.cells[i].centre);for(std::size_t id=0;id<mesh.faces.size();++id){fixed[id]=true;bc[id]=linear(mesh.faces[id].centre);}segment_study::Stencil affine(mesh,fixed);const auto affineG=affine.apply(value,bc);double affineError=0;for(const auto& g:affineG)affineError=std::max(affineError,std::hypot(g.x-.3,g.y+.7));
    std::cout<<std::setprecision(17)<<"{\"cells\":"<<mesh.cells.size()<<",\"originalBoundarySegments\":"<<mesh.faces.size()<<",\"splitFaces\":"<<split.faces.size()<<",\"originalGroupedSamples\":"<<a.groupedFaces<<",\"originalChangedCells\":"<<a.changedCells<<",\"nativeSplitGradientL2\":"<<std::sqrt(double(originalL2/area))<<",\"nativeSplitGradientMax\":"<<originalMax<<",\"aggregateSplitGradientL2\":"<<std::sqrt(double(aggregateL2/area))<<",\"aggregateSplitGradientMax\":"<<aggregateMax<<",\"nativeVsAggregateMax\":"<<changeMax<<",\"aggregateAffineMaxError\":"<<affineError<<",\"productChangedCells\":"<<productChangedCells<<",\"productGroupedFaces\":"<<productGroupedFaces<<",\"productVsPrototypeMax\":"<<productVsPrototype<<",\"productSplitMax\":"<<productSplitMax<<",\"cacheDifferenceMax\":"<<cacheDifference<<"}\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}}
