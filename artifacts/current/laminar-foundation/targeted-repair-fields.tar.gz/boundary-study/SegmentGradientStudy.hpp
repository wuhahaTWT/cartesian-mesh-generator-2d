#pragma once
#include "cartmesh2d/fv/detail/FlowFaceOperators2D.hpp"
#include <map>
// Research-only: replace repeated collinear boundary samples by their
// length-weighted face mean. Faces, BC values and all FV fluxes are untouched.
namespace segment_study {
using namespace cartmesh2d;
using namespace cartmesh2d::fv;
struct Group { std::optional<std::size_t> neighbour; std::vector<std::size_t> faces; };
inline bool samePlane(const Face& a,const Face& b) {
    const double la=std::hypot(a.areaVector.x,a.areaVector.y),lb=std::hypot(b.areaVector.x,b.areaVector.y);
    const auto na=a.areaVector*(1/la),nb=b.areaVector*(1/lb);
    const auto delta=b.centre-a.centre;
    // Only floating-point-equivalent planes are grouped. This is a research
    // roundoff budget, not a mesh-quality or solution acceptance tolerance.
    const double eps=128*std::numeric_limits<double>::epsilon();
    const double coordinate=std::max({1.,std::abs(a.centre.x),std::abs(a.centre.y),std::abs(b.centre.x),std::abs(b.centre.y)});
    return na.x*nb.x+na.y*nb.y>0 &&
        std::abs(na.x*nb.y-na.y*nb.x)<=eps*coordinate/std::min(la,lb) &&
        std::abs(delta.x*na.x+delta.y*na.y)<=eps*coordinate;
}
struct Stencil {
    struct Sample { std::optional<std::size_t> neighbour;std::vector<std::pair<std::size_t,double>> boundary; Vector2D d;double length;bool zero; };
    struct Row { std::vector<Sample> samples;double xx=0,xy=0,yy=0,det=0; };
    std::vector<Row> rows;
    std::size_t groupedFaces=0,changedCells=0;
    Stencil(const FvMesh2D& m,const std::vector<bool>& fixed) {
        rows.resize(m.cells.size());
        for(std::size_t i=0;i<m.cells.size();++i) {
            std::vector<Group> groups;
            for(const auto id:m.cells[i].faces) {
                const auto& f=m.faces[id];const auto j=f.owner==i?f.neighbour:std::optional<std::size_t>(f.owner);
                auto it=groups.end();
                if(!j)it=std::find_if(groups.begin(),groups.end(),[&](const auto& group){const auto fid=group.faces.front();return !group.neighbour && fixed[fid]==fixed[id] && m.faces[fid].patch==f.patch && samePlane(m.faces[fid],f);});
                if(it==groups.end())groups.push_back({j,{id}});else it->faces.push_back(id);
            }
            if(groups.size()!=m.cells[i].faces.size()){++changedCells;groupedFaces+=m.cells[i].faces.size()-groups.size();}
            auto& row=rows[i];
            for(const auto& group:groups) {
                Sample sample;sample.neighbour=group.neighbour;sample.zero=!group.neighbour&&!fixed[group.faces.front()];sample.length=1.;
                if(group.neighbour)sample.d=m.cells[*group.neighbour].centre-m.cells[i].centre;
                else if(!sample.zero) {
                    double length=0;Point2D centre{};
                    for(const auto id:group.faces){const double l=std::hypot(m.faces[id].areaVector.x,m.faces[id].areaVector.y);length+=l;centre.x+=l*m.faces[id].centre.x;centre.y+=l*m.faces[id].centre.y;sample.boundary.emplace_back(id,l);}
                    for(auto& [id,w]:sample.boundary)w/=length;
                    sample.d=Point2D{centre.x/length,centre.y/length}-m.cells[i].centre;
                } else sample.d=m.faces[group.faces.front()].areaVector;
                const double length=std::hypot(sample.d.x,sample.d.y);if(!(length>0))throw std::runtime_error("Study degenerate sample");
                if(!sample.zero)sample.length=length;sample.d=sample.d*(1/length);
                row.xx+=sample.d.x*sample.d.x;row.xy+=sample.d.x*sample.d.y;row.yy+=sample.d.y*sample.d.y;row.samples.push_back(std::move(sample));
            }
            row.det=row.xx*row.yy-row.xy*row.xy;
            if(!(row.det>64*std::numeric_limits<double>::epsilon()*(row.xx+row.yy)*(row.xx+row.yy)))throw std::runtime_error("Study rank deficient");
        }
    }
    std::vector<Vector2D> apply(const std::vector<double>& value,const std::vector<double>& bc) const {
        std::vector<Vector2D> result(rows.size());
        for(std::size_t i=0;i<rows.size();++i){const auto& row=rows[i];double bx=0,by=0;
            for(const auto& s:row.samples){double other=0;if(s.neighbour)other=value[*s.neighbour];else for(const auto& [id,w]:s.boundary)other+=w*bc[id];
                const double delta=s.zero?0:(other-value[i])/s.length;bx+=s.d.x*delta;by+=s.d.y*delta;}
            result[i]={(row.yy*bx-row.xy*by)/row.det,(row.xx*by-row.xy*bx)/row.det};}
        return result;
    }
};
inline std::vector<Vector2D> gradient(const FvMesh2D& m,const std::vector<double>& value,const std::vector<double>& bc,const std::vector<bool>& fixed){
    struct Cache{const FvMesh2D* mesh=nullptr;std::vector<bool> fixed;std::optional<Stencil> stencil;};
    static thread_local Cache caches[2];auto& cache=caches[fixed.empty()?0:fixed.front()?1:0];
    if(cache.mesh!=&m||cache.fixed!=fixed){cache.mesh=&m;cache.fixed=fixed;cache.stencil.emplace(m,fixed);}return cache.stencil->apply(value,bc);
}
extern int variant;
}
