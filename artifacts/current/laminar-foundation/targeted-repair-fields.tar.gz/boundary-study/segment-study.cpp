#include "SegmentGradientStudy.hpp"
#include "cartmesh2d/fv/FlowBoundaryIO2D.hpp"
#include "cartmesh2d/io/MeshIO2D.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <chrono>
int segment_study::variant=0;
using namespace cartmesh2d;
using namespace cartmesh2d::fv;
int main(int argc,char** argv){try {
    if(argc!=6)throw std::runtime_error("segment-study MESH BC annulus|dfg VARIANT PREFIX");
    const auto started=std::chrono::steady_clock::now();auto input=readCm2dTopology(argv[1]);if(!input.valid())throw std::runtime_error(input.error);const auto mesh=makeFvMesh2D(input.topology);
    segment_study::variant=std::stoi(argv[4]);const bool annulus=std::string(argv[3])=="annulus";
    FlowControls2D c;c.scenario="custom";c.nu=annulus?.1:.001;c.speed=annulus?.5:.2;c.tolerance=1e-8;c.maxIterations=40;
    c.coupling=FlowCoupling2D::Coupled;c.convection=ConvectionScheme2D::FaceLimitedLinearUpwind;c.adaptiveLinear=true;
    std::ifstream bc(argv[2]);c.boundaryConditions=readFlowBoundaryConditions2D(bc,mesh,c);
    std::vector<bool> fixed(mesh.faces.size());for(const auto& b:c.boundaryConditions)fixed[b.face]=b.kind!=FlowBoundaryKind2D::PressureOutlet&&b.kind!=FlowBoundaryKind2D::PressureOpening&&b.kind!=FlowBoundaryKind2D::VelocityOutlet;
    segment_study::Stencil stencil(mesh,fixed);
    std::cerr<<"cells="<<mesh.cells.size()<<" groupedFaces="<<stencil.groupedFaces<<" changedCells="<<stencil.changedCells<<'\n';
    const auto result=solveIncompressible2D(mesh,c,[](const auto& h){std::cerr<<"iteration="<<h.iteration<<" momentum="<<h.momentumResidual<<" flux="<<h.fluxConsistency<<'\n';});
    const auto& h=result.history.back();long double area=0,u2=0,p2=0,pmean=0;
    const auto exactP=[](Point2D x){const double r2=x.x*x.x+x.y*x.y;return r2/18.-std::log(r2)/9.-1./(18.*r2);};
    const double gauge=annulus?exactP(mesh.cells[0].centre):0;
    std::ofstream fields(std::string(argv[5])+".cells.csv");fields<<std::setprecision(17)<<"cell,x,y,area,u,v,p\n";
    for(std::size_t i=0;i<mesh.cells.size();++i){const auto& cell=mesh.cells[i];area+=cell.area;const auto x=cell.centre;
        if(annulus){const double q=-1./3.+1./(3*(x.x*x.x+x.y*x.y)),du=result.u[i]+x.y*q,dv=result.v[i]-x.x*q,dp=result.p[i]-(exactP(x)-gauge);u2+=cell.area*(du*du+dv*dv);p2+=cell.area*dp*dp;pmean+=cell.area*dp;}
        fields<<i<<','<<x.x<<','<<x.y<<','<<cell.area<<','<<result.u[i]<<','<<result.v[i]<<','<<result.p[i]<<'\n';}
    std::ofstream out(std::string(argv[5])+".json");out<<std::setprecision(17)<<"{\"variant\":"<<segment_study::variant<<",\"cells\":"<<mesh.cells.size()<<",\"groupedFaces\":"<<stencil.groupedFaces<<",\"changedCells\":"<<stencil.changedCells<<",\"converged\":"<<(result.converged?"true":"false")<<",\"iterations\":"<<h.iteration<<",\"momentumResidual\":"<<h.momentumResidual<<",\"continuity\":"<<h.continuity<<",\"fluxConsistency\":"<<h.fluxConsistency<<",\"velocityL2\":"<<std::sqrt(double(u2/area))/c.speed<<",\"pressureMeanFreeL2\":"<<std::sqrt(std::max(0.,double(p2/area-pmean*pmean/(area*area))))/(c.speed*c.speed)<<",\"wallSeconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()<<",\"loads\":[";
    for(std::size_t i=0;i<result.namedWallLoads.size();++i){if(i)out<<',';const auto& load=result.namedWallLoads[i];out<<"{\"name\":\""<<load.name<<"\",\"pressureX\":"<<load.pressure.x<<",\"pressureY\":"<<load.pressure.y<<",\"viscousX\":"<<load.viscous.x<<",\"viscousY\":"<<load.viscous.y<<",\"torque\":"<<load.pressureTorque+load.viscousTorque<<'}';}out<<"]}\n";
    std::cerr<<"converged="<<result.converged<<" reason="<<result.failureReason<<'\n';return result.converged?0:1;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}}
